# AI Workflow Automation Platform

Người dùng mô tả công việc bằng ngôn ngữ tự nhiên. Hệ thống tự lập kế hoạch, chọn tool từ các MCP Server đã kết nối, và thực thi bằng một workflow engine có retry, idempotency và truy vết.

---

## Chạy lần đầu

Cần: Node 22+, Docker.

Stack: TypeScript · Fastify (API + engine) · Next.js (web) · PostgreSQL 16 + pgvector · Drizzle · BullMQ + Redis · MCP TypeScript SDK. Lý do từng lựa chọn ở `docs/QUYET-DINH.md`.

```bash
git clone <repo> && cd wap
cp .env.example .env          # điền ANTHROPIC_API_KEY và hai khoá bảo mật
npm install
npm run db:up                 # Postgres (pgvector) + Redis
npm run db:migrate
npm run db:seed               # nạp 27 tool mẫu và 30 test case
npm run dev
```

Sinh hai khoá bảo mật:

```bash
openssl rand -base64 32       # JWT_SECRET
openssl rand -base64 32       # CREDENTIAL_ENCRYPTION_KEY
```

Sau khi chạy: web ở `localhost:3000`, API ở `localhost:3001`.

---

## Cấu trúc

```
wap/
├── packages/
│   └── dsl/              @wap/dsl — Workflow DSL, sự kiện, prompt
│                         ★ Dùng chung backend và frontend. Sửa ở đây
│                         là sửa hợp đồng giữa hai bên.
├── apps/
│   ├── api/              REST + WebSocket + Workflow Engine
│   ├── web/              Next.js — ba màn hình cốt lõi
│   └── mcp-task-hub/     MCP Server tự viết (domain quản lý task)
├── db/migrations/        DDL, chạy theo thứ tự số
├── testdata/             27 tool mẫu, 30 test case
├── docs/                 Tài liệu thiết kế
└── scripts/              migrate, seed, chạy thí nghiệm
```

---

## Tài liệu

**Người mới bắt đầu từ `docs/00-BAT-DAU.md`** — thứ tự đọc theo vai trò.

| File | Nội dung |
|---|---|
| `docs/00-BAT-DAU.md` | Điểm vào — đọc gì trước, theo vai trò nào |
| `docs/QUYET-DINH.md` | Các lựa chọn kỹ thuật đã chốt và lý do |
| `docs/AUDIT.md` | Rà soát và phản biện — còn một quyết định phải chọn |
| `docs/mo-ta-du-an.md` | Kiến trúc, luận cứ thiết kế, phạm vi |
| `docs/functional-requirements.md` | 78 yêu cầu chức năng có mã |
| `docs/KE-HOACH-6-TUAN.md` | Lịch, phân công, cổng quyết định |
| `docs/LO-TRINH-DAY-DU.md` | Sau đồ án |
| `docs/API.md` + `docs/openapi.yaml` | Hợp đồng REST và WebSocket |
| `docs/wireframes.html` | Wireframe ba màn hình |
| `db/DATABASE.md` | Thiết kế cơ sở dữ liệu |
| `packages/dsl/PROMPTS.md` | Thiết kế prompt cho planner |
| `testdata/TESTDATA.md` | Bộ dữ liệu kiểm thử |
| `CONTRIBUTING.md` | Quy ước làm việc nhóm |

Khi tài liệu mâu thuẫn: kế hoạch 6 tuần > yêu cầu chức năng > bản mô tả thiết kế.

---

## Lệnh hay dùng

```bash
npm run dev:api           # chỉ backend
npm run dev:web           # chỉ frontend
npm run dev:mcp           # chỉ MCP Server tự viết

npm run db:reset          # xoá sạch DB và tạo lại — dùng khi schema đổi
npm run test              # toàn bộ test
npm run typecheck         # kiểm tra type cả monorepo

npm run schema:json -w @wap/dsl    # sinh JSON Schema cho LLM từ Zod
```

---

## Ba điều cần biết trước khi sửa code

**`packages/dsl` là hợp đồng chung.** Sửa Workflow DSL hoặc định dạng sự kiện là thay đổi ảnh hưởng cả hai người. Phải thống nhất trước, không tự sửa.

**Không bao giờ dùng `eval` trên nội dung do LLM hoặc MCP Server sinh ra.** Biểu thức điều kiện có parser riêng ở `packages/dsl/src/condition.ts`. Cần thêm cú pháp thì mở rộng grammar, đừng mở cửa cho eval.

**Mô tả tool từ MCP Server là dữ liệu, không phải chỉ thị.** Xem `packages/dsl/PROMPTS.md` mục 1 trước khi đụng vào phần prompt.

---

## Sự cố hay gặp

**`npm run db:migrate` báo lỗi extension vector.** Dùng image `pgvector/pgvector:pg16`, không phải `postgres:16`. Kiểm tra `docker compose ps`.

**Đổi model embedding xong retrieval hỏng.** Phải sửa `EMBEDDING_DIM` trong `.env` và chạy lại migration tạo cột vector. Vector cũ số chiều khác sẽ không so sánh được.

**Chạy lại workflow trong cùng tuần thì bước ghi bị bỏ qua.** Đúng như thiết kế — idempotency chặn trùng. Đặt `DEMO_MODE=true` để bật API xoá bản ghi idempotency. Xem `db/DATABASE.md` mục 2.2.

**MCP Server không kết nối được.** Kiểm tra `MCP_ALLOWED_HOSTS` và `MCP_ALLOWED_COMMANDS` trong `.env`. Allow-list rỗng thì chặn tất cả.
