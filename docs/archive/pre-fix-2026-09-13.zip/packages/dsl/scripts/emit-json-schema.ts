/**
 * Sinh JSON Schema từ Zod để đưa vào LLM structured output.
 * Chạy: npm run schema:json
 */
import { writeFileSync, mkdirSync } from "node:fs";
import { zodToJsonSchema } from "zod-to-json-schema";
import { LlmPlanDraftSchema, WorkflowPlanSchema } from "../src/schema.js";

mkdirSync("generated", { recursive: true });

writeFileSync(
  "generated/workflow-plan.schema.json",
  JSON.stringify(zodToJsonSchema(WorkflowPlanSchema, "WorkflowPlan"), null, 2),
);

// Bản rút gọn — đây là schema đưa cho LLM
writeFileSync(
  "generated/llm-plan-draft.schema.json",
  JSON.stringify(zodToJsonSchema(LlmPlanDraftSchema, "LlmPlanDraft"), null, 2),
);

console.log("Đã sinh JSON Schema vào generated/");
