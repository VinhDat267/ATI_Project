# Thiết kế Prompt cho Planner

Code ở `src/prompts.ts`. Tài liệu này giải thích *vì sao* prompt được viết như vậy — phần cần trình bày khi bảo vệ.

---

## 1. Bốn lớp phòng vệ chống tool poisoning

Mô tả tool đến từ MCP Server của bên thứ ba. Một server độc hại có thể nhét chỉ thị vào phần `description` để chiếm quyền điều khiển agent. Đây là lỗ hổng đã biết trong hệ sinh thái MCP (NFR-08).

| Lớp | Cách làm | Ở đâu |
|---|---|---|
| 1 | Nội dung bên thứ ba nằm trong khối có ranh giới rõ | `buildToolCatalog()` |
| 2 | System prompt nói thẳng: khối đó là dữ liệu, không phải lệnh | `buildSystemPrompt()` |
| 3 | Vô hiệu hoá ký tự phá khối trước khi ghép | `neutralize()` |
| 4 | Validator tầng 2 chặn tool không có trong Registry | `graph.ts` + tool validator |

**Lớp 4 là lớp quan trọng nhất** và cần nhấn mạnh khi bảo vệ: ba lớp đầu chỉ giảm xác suất LLM bị dụ. Lớp 4 mới là đảm bảo cứng — dù LLM có sinh ra tool bịa hay tham số lạ, kế hoạch đó không qua được validate nên không bao giờ chạy. Đây là lợi ích trực tiếp của kiến trúc plan-then-execute.

`neutralize()` cố ý **không** cố phát hiện ý đồ xấu — việc đó không đáng tin cậy và dễ tạo cảm giác an toàn giả. Nó chỉ đảm bảo nội dung không phá được ranh giới khối: thay chuỗi `═══`, gộp dòng trống liên tiếp (tránh tạo khoảng cách thị giác giả), và cắt độ dài.

Đã kiểm thử với ba kiểu tấn công: giả mạo dấu đóng khối, làm ngập dòng trống để đẩy nội dung ra xa, và mô tả quá dài. Cả ba đều không phá được ranh giới.

---

## 2. Các quyết định khác trong system prompt

**"Khi phân vân, chọn write."** Đoán sai theo hướng an toàn chỉ tốn một bước xác nhận. Đoán sai theo hướng còn lại thì một hành động ghi lọt qua dry-run mà người dùng không kịp thấy.

**Cấm tự tính ngày tháng.** LLM tính ngày sai thường xuyên và sai một cách khó phát hiện — "tuần trước" lệch một ngày thì báo cáo vẫn chạy, chỉ là sai dữ liệu. Đưa sẵn `${runtime.week_start}` loại bỏ hoàn toàn nhóm lỗi này.

**Lối thoát "KHÔNG THỂ:".** Không có lối thoát thì mô hình sẽ cố nặn ra kế hoạch dù không có tool phù hợp — thường bằng cách bịa tool hoặc dùng sai tool. Cho phép nói không làm được sẽ đổi một nhóm lỗi âm thầm thành một thông báo rõ ràng.

**Nhắc lại quy tắc depends_on hai lần** (quy tắc 5 và 6). Đây là lỗi phổ biến nhất: LLM viết `${steps.s1.output.x}` nhưng quên khai báo `depends_on: ["s1"]`. Validator tầng 3 bắt được, nhưng bắt trước ở prompt thì tiết kiệm một vòng sửa.

---

## 3. Prompt sửa lỗi (repair)

Ba điểm đáng chú ý trong `buildRepairPrompt()`:

**Nhóm lỗi theo tầng.** Lỗi cấu trúc, lỗi tool, lỗi đồ thị cần cách sửa khác nhau. Trộn chung thành một danh sách phẳng khiến mô hình khó ưu tiên.

**"Giữ nguyên phần đã đúng — đừng viết lại từ đầu."** Không có câu này, mô hình thường sinh lại toàn bộ và tạo ra lỗi mới ở chỗ vốn đã đúng.

**Danh sách cách đã thử thất bại.** Tránh việc mô hình lặp đúng sai lầm cũ ở vòng sửa thứ hai, thứ ba.

---

## 4. Prompt replan

`buildReplanPrompt()` khác repair ở chỗ: lỗi xảy ra lúc **thực thi**, nên có dữ liệu thật để dựa vào.

Điểm quan trọng nhất là truyền **output thật của các bước đã chạy xong**. Ví dụ nếu bước 1 trả về danh sách rỗng và bước 2 lỗi vì thế, mô hình cần thấy danh sách rỗng đó để hiểu vấn đề nằm ở giả định ban đầu, không phải ở tham số của bước 2.

Ba phạm vi sửa (`local`, `partial`, `full`) có chỉ dẫn riêng, tương ứng bảng phân loại lỗi ở mục 5.4 của bản mô tả dự án. Nguyên tắc chung: giữ lại tối đa phần đã chạy thành công, chỉ sinh lại phần nhỏ nhất cần thiết.

---

## 5. Những thứ cần đo và điều chỉnh sau

Prompt là thứ **phải tinh chỉnh bằng số liệu**, không phải viết một lần là xong. Bảng `planning_attempts` trong database đã lưu sẵn những gì cần:

- Tỷ lệ pass ngay lần đầu, theo từng mức độ phức tạp của test case
- Lỗi nào hay gặp nhất (nhóm theo `validation_errors.layer`) — lỗi nào lặp nhiều thì bổ sung quy tắc vào system prompt
- Số token tiêu thụ — nếu danh mục tool chiếm phần lớn, đó là bằng chứng cho giá trị của Tool Retrieval

Gợi ý quy trình: viết prompt phiên bản đầu, chạy trên 20-30 test case, xem lỗi nào lặp lại, bổ sung đúng quy tắc cho lỗi đó, đo lại. Ghi chép các phiên bản prompt và kết quả tương ứng — đây là nội dung tốt cho phần đánh giá trong báo cáo, và cho thấy quá trình làm có phương pháp.

---

## 6. Chưa có, cân nhắc thêm sau

**Few-shot examples.** Hiện chưa có ví dụ mẫu trong prompt. Nếu tỷ lệ pass lần đầu thấp, thêm 2-3 ví dụ kế hoạch đúng (đơn giản, có nhánh song song, có điều kiện) thường cải thiện rõ. Đánh đổi: tốn thêm token mỗi lần gọi.

**Prompt caching.** System prompt và danh mục tool khá dài và ít thay đổi giữa các lần gọi. Nếu chi phí hoặc độ trễ thành vấn đề, đây là chỗ tối ưu đầu tiên.

**Hỏi lại khi mơ hồ (FR-PLN-12).** Hiện mô hình chỉ có thể trả "KHÔNG THỂ:". Một bước trung gian — trả về câu hỏi làm rõ thay vì từ chối hẳn — sẽ tốt hơn cho trải nghiệm, nhưng cần thêm một trạng thái run mới và một màn hình nữa.
