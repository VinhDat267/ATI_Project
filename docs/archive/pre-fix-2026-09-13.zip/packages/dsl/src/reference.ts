/**
 * Biểu thức tham chiếu  ${namespace.path}
 *
 * Ba namespace hợp lệ:
 *   ${inputs.<key>}                  — tham số đầu vào
 *   ${steps.<stepId>.output.<path>}  — output của bước trước
 *   ${runtime.<var>}                 — giá trị hệ thống cấp
 *
 * Không dùng eval ở bất kỳ đâu (NFR-09).
 */

import {
  REFERENCE_GLOBAL,
  REFERENCE_ONLY,
  RUNTIME_VARS,
  type ArgValue,
  type RuntimeVar,
} from "./schema.js";

/* ────────────────────────────────────────────────────────────
 * Kiểu
 * ──────────────────────────────────────────────────────────── */

export type Reference =
  | { kind: "input"; key: string; raw: string }
  | { kind: "step"; stepId: string; path: string[]; raw: string }
  | { kind: "runtime"; name: RuntimeVar; raw: string };

export class ReferenceError_ extends Error {
  constructor(
    message: string,
    readonly raw: string,
  ) {
    super(message);
    this.name = "ReferenceError_";
  }
}

/* ────────────────────────────────────────────────────────────
 * Phân tích
 * ──────────────────────────────────────────────────────────── */

/** Phân tích một tham chiếu đơn, ví dụ "${steps.s1.output.count}". */
export function parseReference(raw: string): Reference {
  if (!REFERENCE_ONLY.test(raw)) {
    throw new ReferenceError_("không phải biểu thức tham chiếu hợp lệ", raw);
  }

  const inner = raw.slice(2, -1).trim();
  const parts = inner.split(".");
  const [ns, ...rest] = parts;

  switch (ns) {
    case "inputs": {
      if (rest.length !== 1) {
        throw new ReferenceError_("inputs chỉ nhận đúng một cấp: ${inputs.<key>}", raw);
      }
      return { kind: "input", key: rest[0]!, raw };
    }

    case "steps": {
      // steps.<stepId>.output[.path...]
      if (rest.length < 2 || rest[1] !== "output") {
        throw new ReferenceError_(
          "tham chiếu step phải có dạng ${steps.<stepId>.output...}",
          raw,
        );
      }
      return { kind: "step", stepId: rest[0]!, path: rest.slice(2), raw };
    }

    case "runtime": {
      if (rest.length !== 1) {
        throw new ReferenceError_("runtime chỉ nhận đúng một cấp: ${runtime.<var>}", raw);
      }
      const name = rest[0]!;
      if (!(RUNTIME_VARS as readonly string[]).includes(name)) {
        throw new ReferenceError_(
          `biến runtime không tồn tại: "${name}" (hợp lệ: ${RUNTIME_VARS.join(", ")})`,
          raw,
        );
      }
      return { kind: "runtime", name: name as RuntimeVar, raw };
    }

    default:
      throw new ReferenceError_(
        `namespace không hợp lệ: "${ns}" (hợp lệ: inputs, steps, runtime)`,
        raw,
      );
  }
}

/** Trích mọi tham chiếu nhúng trong một chuỗi. */
export function extractReferences(text: string): Reference[] {
  const out: Reference[] = [];
  for (const m of text.matchAll(REFERENCE_GLOBAL)) {
    out.push(parseReference(`\${${m[1]}}`));
  }
  return out;
}

/** Duyệt đệ quy một cây ArgValue, thu thập mọi tham chiếu. */
export function collectReferences(value: ArgValue): Reference[] {
  if (typeof value === "string") return extractReferences(value);
  if (Array.isArray(value)) return value.flatMap(collectReferences);
  if (value !== null && typeof value === "object") {
    return Object.values(value).flatMap(collectReferences);
  }
  return [];
}

/* ────────────────────────────────────────────────────────────
 * Resolve (FR-EXE-03)
 * ──────────────────────────────────────────────────────────── */

export interface ResolveContext {
  inputs: Record<string, string | number | boolean>;
  /** stepId -> output đã trả về của bước đó */
  stepOutputs: Record<string, unknown>;
  runtime: Record<RuntimeVar, string>;
}

function lookupPath(root: unknown, path: string[], raw: string): unknown {
  let cur: unknown = root;
  for (const seg of path) {
    if (cur === null || cur === undefined) {
      throw new ReferenceError_(`đường dẫn "${path.join(".")}" gặp giá trị null`, raw);
    }
    if (typeof cur !== "object") {
      throw new ReferenceError_(
        `đường dẫn "${path.join(".")}" đi vào giá trị không phải object`,
        raw,
      );
    }
    // Hỗ trợ chỉ số mảng dạng số
    if (Array.isArray(cur)) {
      const idx = Number(seg);
      if (!Number.isInteger(idx)) {
        throw new ReferenceError_(`"${seg}" không phải chỉ số mảng hợp lệ`, raw);
      }
      cur = cur[idx];
    } else {
      cur = (cur as Record<string, unknown>)[seg];
    }
  }
  return cur;
}

/** Lấy giá trị của một tham chiếu từ context. */
export function resolveReference(ref: Reference, ctx: ResolveContext): unknown {
  switch (ref.kind) {
    case "input": {
      if (!(ref.key in ctx.inputs)) {
        throw new ReferenceError_(`input "${ref.key}" chưa được cung cấp`, ref.raw);
      }
      return ctx.inputs[ref.key];
    }
    case "runtime":
      return ctx.runtime[ref.name];
    case "step": {
      if (!(ref.stepId in ctx.stepOutputs)) {
        throw new ReferenceError_(
          `bước "${ref.stepId}" chưa chạy hoặc không có output`,
          ref.raw,
        );
      }
      return lookupPath(ctx.stepOutputs[ref.stepId], ref.path, ref.raw);
    }
  }
}

/**
 * Resolve một giá trị đối số.
 *
 * - Chuỗi CHỈ chứa một tham chiếu  → trả về giá trị gốc, GIỮ NGUYÊN KIỂU
 *   ("${steps.s1.output.count}" → 12, không phải "12")
 * - Chuỗi có tham chiếu nhúng      → nội suy thành chuỗi
 * - Mảng / object                  → đệ quy
 */
export function resolveValue(value: ArgValue, ctx: ResolveContext): unknown {
  if (typeof value === "string") {
    if (REFERENCE_ONLY.test(value)) {
      return resolveReference(parseReference(value), ctx);
    }
    return value.replace(REFERENCE_GLOBAL, (_match, inner: string) => {
      const v = resolveReference(parseReference(`\${${inner}}`), ctx);
      return v === null || v === undefined ? "" : String(v);
    });
  }

  if (Array.isArray(value)) return value.map((v) => resolveValue(v, ctx));

  if (value !== null && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) out[k] = resolveValue(v, ctx);
    return out;
  }

  return value;
}

/** Resolve toàn bộ args của một tool. */
export function resolveArgs(
  args: Record<string, ArgValue>,
  ctx: ResolveContext,
): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(args)) out[k] = resolveValue(v, ctx);
  return out;
}

/* ────────────────────────────────────────────────────────────
 * Giá trị runtime (FR-PLN-08)
 * ──────────────────────────────────────────────────────────── */

export function buildRuntime(opts: {
  now?: Date;
  runId: string;
  userId: string;
  /** 1 = thứ Hai (mặc định, theo ISO-8601) */
  weekStartsOn?: 0 | 1;
}): Record<RuntimeVar, string> {
  const now = opts.now ?? new Date();
  const weekStartsOn = opts.weekStartsOn ?? 1;

  const startOfDay = (d: Date) =>
    new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));

  const day = now.getUTCDay();
  const diff = (day - weekStartsOn + 7) % 7;

  const weekStart = startOfDay(now);
  weekStart.setUTCDate(weekStart.getUTCDate() - diff);

  const weekEnd = new Date(weekStart);
  weekEnd.setUTCDate(weekEnd.getUTCDate() + 6);

  const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const monthEnd = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 0));

  const iso = (d: Date) => d.toISOString();
  const date = (d: Date) => d.toISOString().slice(0, 10);

  return {
    now: iso(now),
    today: date(now),
    week_start: date(weekStart),
    week_end: date(weekEnd),
    month_start: date(monthStart),
    month_end: date(monthEnd),
    run_id: opts.runId,
    user_id: opts.userId,
  };
}
