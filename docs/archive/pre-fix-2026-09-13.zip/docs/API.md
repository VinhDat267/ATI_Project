# API Contract

Hợp đồng giữa backend và frontend. Đây là **mặt tiếp giáp thứ hai** giữa hai người trong nhóm (mặt thứ nhất là Workflow DSL).

- `openapi.yaml` — 18 endpoint REST
- `../src/events.ts` — 13 loại sự kiện WebSocket, định nghĩa bằng Zod, dùng chung hai đầu

---

## 1. Ba nguyên tắc

### 1.1. `run` là tài nguyên trung tâm

Toàn bộ vòng đời — sinh kế hoạch, validate, dry-run, chờ duyệt, thực thi, replan — diễn ra trên cùng một `run`. Frontend theo dõi một đối tượng duy nhất từ lúc người dùng bấm gửi đến lúc kết thúc.

Thiết kế thay thế (mỗi giai đoạn một tài nguyên riêng: `plan`, `approval`, `execution`) sẽ buộc frontend phải nối ba luồng lại với nhau, và làm màn hình trace phức tạp hơn nhiều mà không được gì.

### 1.2. Không endpoint nào chặn chờ LLM

`POST /runs` trả `202 Accepted` kèm `run_id` ngay lập tức. Sinh kế hoạch mất khoảng 15 giây (NFR-01), dry-run mất thêm vài giây nữa — chặn HTTP suốt thời gian đó vừa dễ timeout vừa không cho người dùng thấy tiến trình.

Đổi lại, frontend phải xử lý trạng thái trung gian ngay từ đầu. Đó là việc phải làm dù sao, vì màn hình trace cần nó.

### 1.3. REST và WebSocket dùng chung định dạng sự kiện

`GET /runs/{id}/events?since_seq=` trả về đúng cấu trúc mà WebSocket đẩy xuống. Nhờ vậy frontend viết **một** hàm xử lý sự kiện, dùng cho cả ba tình huống: xem trực tiếp, nối lại sau mất kết nối, và xem lại run đã kết thúc.

---

## 2. Luồng chính

### 2.1. Từ mô tả tới hoàn tất

```
Client                          Server                      Engine
  │                                │                           │
  ├─ POST /runs {prompt} ─────────►│                           │
  │◄──── 202 {run_id} ─────────────┤                           │
  │                                │                           │
  ├─ WS subscribe {run_id, seq:0} ►│                           │
  │◄──── subscribed {current_seq} ─┤                           │
  │                                │                           │
  │◄──── run.status: planning ─────┤                           │
  │◄──── validation.failed (1/3) ──┤  ← vòng sửa, nếu có       │
  │◄──── plan.ready {plan, layers}─┤                           │
  │      [vẽ sơ đồ DAG]            │                           │
  │◄──── run.status: dry_running ──┤                           │
  │◄──── step.succeeded (read) ────┤  ← bước read chạy thật    │
  │◄──── dryrun.ready {approval} ──┤                           │
  │      [hiện màn hình duyệt]     │                           │
  │                                │                           │
  ├─ POST /runs/{id}/approve ─────►│                           │
  │◄──── 202 ──────────────────────┤─── đưa vào hàng đợi ─────►│
  │                                │                           │
  │◄──── run.status: running ──────┤◄──────────────────────────┤
  │◄──── step.started ─────────────┤◄──────────────────────────┤
  │◄──── step.attempt {args} ──────┤◄──────────────────────────┤
  │◄──── step.retrying {2/3, 429} ─┤◄── retry, hiện lên UI ────┤
  │◄──── step.succeeded ───────────┤◄──────────────────────────┤
  │◄──── run.finished ─────────────┤◄──────────────────────────┤
```

### 2.2. Khi có lỗi và replan

```
  │◄──── step.failed {bad_args} ───┤
  │◄──── run.status: replanning ───┤
  │◄──── replan.started {scope:local, failed_step_id} ─┤
  │◄──── replan.applied {plan, changed_step_ids} ──────┤
  │      [vẽ lại DAG, tô đậm bước đã đổi]
  │◄──── run.status: running ──────┤
  │◄──── step.started (chạy lại) ──┤
```

`replan.applied.changed_step_ids` cho frontend biết đúng bước nào đã thay đổi, để làm nổi bật thay vì vẽ lại toàn bộ như mới. Đây là chi tiết nhỏ nhưng làm demo ấn tượng hơn hẳn.

### 2.3. Nối lại sau mất kết nối

```
  │  [mất mạng, last_seq = 42]
  ├─ WS subscribe {run_id, since_seq: 42} ►│
  │◄──── subscribed {current_seq: 57} ─────┤
  │◄──── event seq 43 ─────────────────────┤
  │◄──── ... ──────────────────────────────┤
  │◄──── event seq 57 ─────────────────────┤
```

Nếu WebSocket không nối lại được, fallback sang `GET /runs/{id}/events?since_seq=42` — cùng dữ liệu.

---

## 3. Quy ước sự kiện

| Quy ước | Lý do |
|---|---|
| `seq` liên tục, không nhảy số | Client phát hiện mất gói bằng cách so sánh với seq trước |
| Payload đủ để cập nhật UI, không cần gọi thêm API | Tránh N+1 request mỗi khi có sự kiện |
| `output_preview` bị cắt nếu quá lớn | Output một bước có thể rất to; bản đầy đủ lấy qua `/trace` |
| Trạng thái kết thúc không có sự kiện tiếp theo | Client đóng kết nối an toàn khi thấy `TERMINAL_STATUSES` |

**Sự kiện quan trọng nhất cho điểm demo: `step.retrying`.** Nếu không phát sự kiện này, cơ chế retry chỉ tồn tại trong log — hội đồng không thấy gì. Phát ra kèm `error_class` và `delay_ms` thì UI hiển thị được "lần 2/3 — lỗi 429, chờ 1s", biến phần reliability thành thứ quan sát được (FR-TRC-03).

---

## 4. Làm việc song song — cách frontend không phải chờ backend

Đây là mục đích chính của việc chốt contract sớm.

**Bước 1 — Sinh type từ OpenAPI.**

```bash
npx openapi-typescript api/openapi.yaml -o src/api-types.ts
```

Frontend có ngay type của mọi response, không phải tự khai báo.

**Bước 2 — Mock REST bằng MSW.** Dựng handler trả dữ liệu mẫu đúng schema. Frontend phát triển đầy đủ ba màn hình mà backend chưa cần chạy.

**Bước 3 — Mock WebSocket bằng cách phát lại một mảng sự kiện.** Viết sẵn một file JSON chứa chuỗi sự kiện của một run mẫu (gồm cả retry và replan), rồi phát ra theo thời gian giả lập. Cách này có ba lợi ích:

- Frontend dựng được màn hình trace hoàn chỉnh trước khi engine tồn tại
- Dùng làm test cố định: mỗi lần sửa UI đều phát lại đúng chuỗi đó
- **Dùng luôn làm phương án dự phòng khi demo** — nếu API ngoài chết giữa buổi bảo vệ, chuyển sang chế độ phát lại vẫn có màn hình chạy đúng

Điểm cuối cùng đáng chú ý: nó biến một công cụ phát triển thành một lớp bảo hiểm cho 10% điểm Demonstration, gần như không tốn thêm công.

---

## 5. Những chỗ còn để mở

Ghi lại để hai người biết là cố ý, không phải quên:

**Phân trang trace.** `GET /runs/{id}/trace` hiện trả toàn bộ. Với workflow 30 bước, mỗi bước 3 lần thử, dữ liệu vẫn nhỏ. Nếu sau này thấy chậm thì thêm phân trang theo `step_id`.

**Xác thực WebSocket.** Chưa quy định. Đơn giản nhất là truyền token qua query string khi mở kết nối, hoặc gửi một message `auth` đầu tiên. Chốt sớm vì nó ảnh hưởng cách frontend mở kết nối.

**Rate limit.** Chưa có. `POST /runs` gọi LLM nên tốn tiền thật — nên thêm giới hạn đơn giản theo người dùng trước khi công khai cho ai khác dùng thử.

**Xoá `idempotency_records` cho demo.** Chưa có endpoint. Cần một cái (chỉ bật ở môi trường demo) vì chạy lại cùng workflow trong cùng tuần sẽ bị bỏ qua bước ghi — xem `DATABASE.md` mục 2.2.
