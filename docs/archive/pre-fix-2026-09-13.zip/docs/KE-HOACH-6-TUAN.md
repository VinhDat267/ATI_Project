# Kế hoạch 6 tuần

2 người · 6 tuần · một codebase TypeScript

---

## 1. Quỹ thời gian đã chốt

Đã ước lượng thật: **5-6 buổi làm việc mỗi tuần mỗi người** (một buổi = khối liền 2-3 giờ), hai người tương đương nhau, không có tuần nào biết trước sẽ mất nhiều thời gian.

| | |
|---|---|
| Mỗi người | ~14 giờ/tuần |
| Tổng 6 tuần | ~165 giờ người |
| **Quỹ xây dựng thật** | **~135 giờ** (tuần 6 không viết code) |

135 giờ nằm giữa hai mức: nhiều hơn cấu hình tối thiểu, ít hơn kế hoạch đầy đủ. Cấu hình ở mục 2 được chốt riêng cho mức này — **đây là phạm vi thi hành, không phải gợi ý**.

Với quỹ đó, **không đủ** cho toàn bộ 45 yêu cầu Must. Quyết định quan trọng nhất của kế hoạch này là cắt sớm và cắt dứt khoát, để 6 tuần cho ra một hệ thống nhỏ hơn nhưng **chạy trọn vẹn** — thứ luôn được điểm cao hơn một hệ thống tham vọng làm dở.

Nguyên tắc phân bổ: **5 tuần code, 1 tuần cho thí nghiệm, báo cáo và demo.** Tuần cuối không viết tính năng mới. Đây là điều khoản không thương lượng — nếu tuần 6 vẫn đang sửa engine thì sẽ không kịp thu số liệu, mà số liệu chiếm phần lớn điểm AI (20%) và Defense (10%).

---

## 2. Cắt ngay từ đầu

| Cắt | Lý do | Mất gì |
|---|---|---|
| Thực thi song song (FR-EXE-11) | Tuần tự vẫn đúng, chỉ chậm hơn | Một điểm demo; vẫn **giữ** `executionLayers()` để vẽ DAG |
| Replan toàn cục và một phần | Giữ replan cục bộ là đủ minh hoạ | Một nhánh của bảng phân loại lỗi |
| Sửa tham số trước khi duyệt (FR-APR-07) | Người dùng có thể từ chối rồi mô tả lại | Tiện lợi, không phải năng lực |
| Bỏ bước (FR-APR-08) | Như trên | Như trên |
| Chạy lại workflow đã lưu (FR-WFM-03/05) | Tạo run mới từ prompt cũ là đủ | Một tính năng, không ảnh hưởng luận điểm |
| Thí nghiệm 2 (one-shot vs incremental) | Tốn thời gian gấp đôi để chạy | Một bảng số liệu; giữ thí nghiệm 1 và 3 |
| Màn hình quản lý kết nối riêng | Gộp vào một panel trong màn hình chính | Chỉ là bố cục |

**Cắt thêm cho mức 135 giờ:**

| Cắt | Lý do | Hệ quả |
|---|---|---|
| Hybrid retrieval (BM25) | Chỉ semantic search + query expansion | Thí nghiệm 1 vẫn chạy được, chỉ ít biến thể hơn |
| MCP Server thứ ba (GitHub) | Hai server là đủ chứng minh tính mở | Mục tiêu phụ — làm nếu tuần 5 còn dư |

Hai server giữ lại: `task_hub` (tự viết) và `filesystem` (công khai, chạy local). Đủ cho kịch bản demo mạnh nhất — cắm một server không phải do mình viết và dùng được ngay — mà lại không phụ thuộc mạng.

**Giữ nguyên, tuyệt đối không cắt:**

| Giữ | Vì sao |
|---|---|
| Ba màn hình cốt lõi | Product Quality + Demonstration = 25% |
| Tool Retrieval (semantic + query expansion) | Trụ thứ nhất của hạng mục AI |
| Replan cục bộ | Trụ thứ hai, và là khoảnh khắc demo mạnh nhất |
| Retry + idempotency | Lõi của Technical Implementation |
| Resume sau crash | Rẻ khi đã có state persistence, mà ăn điểm rõ |
| Dry-run + duyệt | Mất nó là mất luận điểm cốt lõi |
| Validate 3 tầng | Đã có sẵn code trong `@wap/dsl` |
| Video demo dự phòng | Bảo hiểm cho 10% điểm |

Lý do giữ replan cục bộ dù tốn công: cắt hẳn thì phần AI chỉ còn retrieval — quá mỏng cho 20% điểm.

---

## 3. Phân công

| | Người A | Người B |
|---|---|---|
| Trọng tâm | Engine, MCP layer, API | Frontend, MCP Server tự viết, demo |
| Tỷ trọng | ~50% | ~50% |

Hai mặt tiếp giáp đã có sẵn tài liệu: Workflow DSL (`@wap/dsl`) và API contract (`openapi.yaml` + `events.ts`). **Chốt cả hai trong tuần 1**, sau đó hai người làm độc lập.

---

## 4. Lộ trình tuần

> Một số ô ở tuần 3-5 được đánh dấu *(cấu hình A)* hoặc *(cấu hình B)*. Phải chọn cấu hình trước khi tới tuần 3 — xem `docs/QUYET-DINH.md` QĐ-05.

### Tuần 1 — Nền móng và chốt hợp đồng

| Người A | Người B |
|---|---|
| Dựng repo, Docker Compose (Postgres + Redis), chạy migration | Dựng Next.js, sinh type từ `openapi.yaml` |
| MCP Client layer: kết nối, `tools/list`, Tool Registry | MCP Server `task_hub` — trước hết 4 tool đọc |
| Cài `@wap/dsl`, chạy `npm run build` | Dựng MSW mock cho toàn bộ REST |

**Cùng làm ngày 1-2:** rà lại Zod schema DSL và `events.ts`, sửa những gì thấy không ổn, rồi **đóng băng**. Mọi thay đổi sau đó phải cả hai đồng ý.

**Chốt cuối tuần:** kết nối được một MCP Server thật, liệt kê được tool. Frontend chạy được với dữ liệu giả.

---

### Tuần 2 — Engine lõi

| Người A | Người B |
|---|---|
| DAG scheduler (tuần tự), resolve `${...}` | Màn hình 1: nhập mô tả + vẽ DAG từ `layers` |
| State persistence, retry + backoff | Hoàn thiện `task_hub` — thêm tool ghi |
| Idempotency guard | Viết file JSON chuỗi sự kiện mẫu để mock WebSocket |

**Chốt cuối tuần:** chạy được một workflow viết tay bằng JSON, có retry, không side-effect trùng. Đây là cột mốc quan trọng nhất của cả dự án — engine test được độc lập, không phụ thuộc LLM.

---

### Tuần 3 — Planner

| Người A | Người B |
|---|---|
| Gọi LLM với structured output, dùng `prompts.ts` | Màn hình 3: trace real-time (dùng mock trước) |
| Validate 3 tầng + vòng sửa lỗi | Nhận sự kiện: WebSocket *(cấu hình A)* hoặc polling 2 giây *(cấu hình B)* |
| Ghi `planning_attempts` ngay từ đầu | Hiển thị retry, đây là phần quan trọng nhất của màn hình |

**Chốt cuối tuần:** gõ một câu tiếng Việt, ra kế hoạch hợp lệ, chạy được qua engine.

---

### Tuần 4 — An toàn và ghép nối

| Người A | Người B |
|---|---|
| Dry-run: chạy `read`, mô phỏng `write` | Màn hình 2: duyệt dry-run |
| Approval flow · resume sau crash *(chỉ cấu hình A)* | Sinh câu mô tả dễ đọc cho bước ghi |
| `run_events` + tầng phát sự kiện | **Bỏ mock, ghép vào backend thật** |

**Chốt cuối tuần:** luồng end-to-end hoàn chỉnh qua giao diện thật. Đây là thời điểm quay video demo bản đầu tiên — sớm hơn bạn nghĩ là cần, nhưng có video sớm thì tuần 6 đỡ áp lực.

---

### Tuần 5 — Tool Retrieval và Replan

| Người A | Người B |
|---|---|
| Pipeline retrieval: embedding, hybrid search | Kết nối MCP Server thứ hai (GitHub) và thứ ba (filesystem) |
| Ghi `retrieval_logs` | Panel quản lý kết nối (gộp vào màn hình chính) |
| Replan cục bộ + phân loại lỗi | Đánh bóng ba màn hình, xử lý trạng thái lỗi |

**Chốt cuối tuần:** **đóng băng tính năng.** Từ đây chỉ sửa lỗi, không thêm gì mới.

---

### Tuần 6 — Số liệu, báo cáo, demo

| Người A | Người B |
|---|---|
| Nạp 30 test case, chạy thí nghiệm 1 (retrieval) | Quay video demo bản hoàn chỉnh |
| Chạy thí nghiệm 3 (chaos test) | Dựng chế độ mock/phát lại làm dự phòng |
| Truy vấn số liệu, vẽ biểu đồ | Chuẩn bị dữ liệu demo sẵn trong board/sheet |

**Cùng làm:** viết báo cáo, tập bảo vệ, rà lại mục 10 của bản mô tả dự án (câu hỏi phản biện).

---

## 5. Bốn cổng quyết định

Đây là phần quan trọng nhất của kế hoạch. Ở mỗi mốc, nếu chưa đạt thì **cắt ngay**, đừng cố.

| Mốc | Phải đạt | Nếu chưa đạt thì cắt |
|---|---|---|
| Cuối tuần 2 | Engine chạy workflow JSON viết tay, có retry và idempotency | Bỏ `condition`, bỏ resume — chỉ giữ retry + idempotency |
| Cuối tuần 3 | Sinh kế hoạch từ tiếng Việt, pass validate | Giảm còn một MCP Server, giảm tool set xuống 8-10 |
| Cuối tuần 4 | Luồng end-to-end chạy qua giao diện thật | Bỏ replan hẳn, dồn tuần 5 vào đánh bóng và ổn định |
| Cuối tuần 5 | Ba màn hình hoàn chỉnh, hai MCP Server | Bỏ thí nghiệm 1 ở quy mô lớn, chỉ đo trên tool set hiện có |

Cổng cuối tuần 4 là cổng nghiêm khắc nhất. Nếu đến đó chưa có luồng end-to-end chạy được, dự án đang chậm và phải hy sinh replan — vì thà mất một phần điểm AI còn hơn mất điểm Product Quality và Demonstration (25%) do không kịp hoàn thiện.

---

## 6. Nếu bị chậm

Quỹ 135 giờ **không có đệm**. Không có tuần nào biết trước sẽ bận, nhưng thực tế luôn có thứ chen ngang. Khi đó cắt theo thứ tự này:

| Thứ tự cắt | Tiết kiệm | Mất gì |
|---|---|---|
| 1. Query expansion trong retrieval | ~8 giờ | Chỉ còn semantic search thuần; Recall@K vẫn đo được |
| 2. Resume sau crash | ~10 giờ | Vẫn giữ idempotency — vẫn an toàn, chỉ phải chạy lại tay |
| 3. Replan cục bộ | ~15 giờ | Phần AI mỏng đi rõ rệt; chỉ cắt khi đã hết cách |
| 4. Màn hình lịch sử run | ~6 giờ | Gộp tạm vào màn hình trace |

**Không bao giờ cắt để lấy thời gian:** ba màn hình cốt lõi, dry-run, retry + idempotency, và tuần 6.

**Dấu hiệu nhận biết đang chậm** — kiểm tra ở mỗi cổng quyết định ở mục 5:
- Cuối tuần 2 mà engine chưa chạy được workflow JSON viết tay → chậm khoảng một tuần
- Cuối tuần 3 mà chưa sinh được kế hoạch từ tiếng Việt → chậm nghiêm trọng, cắt ngay mục 1 và 2 ở bảng trên
- Cuối tuần 4 mà chưa có luồng end-to-end qua giao diện → cắt mục 3

---

## 7. Ba thói quen nên giữ từ tuần 1

**Ghi số liệu ngay từ đầu.** `planning_attempts` và `retrieval_logs` phải được ghi từ lần chạy đầu tiên, không đợi tuần 6. Nếu không, đến lúc cần số liệu sẽ phải chạy lại toàn bộ test case từ con số không.

**Thêm test case mỗi khi gặp lỗi thật.** Bộ test lớn dần theo lỗi đã gặp là bộ test có giá trị nhất — nó ngăn lỗi cũ quay lại khi bạn sửa prompt cho lỗi mới.

**Quay video demo từ tuần 4.** Quay lại mỗi tuần một bản mới. Tuần 6 chỉ cần quay bản cuối, không phải làm từ đầu dưới áp lực. Và nếu có sự cố ở tuần 6, bạn vẫn còn bản tuần 5 để dùng.
