# AI Workflow Automation Platform

**Bản mô tả chi tiết dự án**

---

## 1. Tổng quan

### 1.1. Tên dự án

**AI Workflow Automation Platform** — Nền tảng tự động hoá quy trình bằng ngôn ngữ tự nhiên.

### 1.2. Bài toán

Các công cụ tự động hoá hiện nay (Zapier, n8n, Make.com) yêu cầu người dùng phải tự thiết kế workflow bằng giao diện kéo-thả: chọn trigger, chọn action, nối các node, cấu hình từng tham số. Việc này đòi hỏi người dùng phải:

- Biết trước hệ thống có những tool nào và mỗi tool làm được gì
- Tự phân rã công việc thành từng bước cụ thể
- Tự xử lý việc chuyển dữ liệu giữa các bước (output của bước A đưa vào tham số nào của bước B)

Rào cản này khiến tự động hoá vẫn là đặc quyền của người có kiến thức kỹ thuật, trong khi nhu cầu thực tế thì đến từ mọi người.

### 1.3. Giải pháp đề xuất

Người dùng chỉ cần **mô tả công việc bằng ngôn ngữ tự nhiên**. Hệ thống sẽ:

1. Đọc danh sách tool khả dụng từ các MCP Server mà người dùng đã kết nối
2. Dùng LLM để **biên dịch** mô tả đó thành một bản kế hoạch có cấu trúc (workflow plan)
3. Kiểm tra tính hợp lệ của kế hoạch qua nhiều tầng validate
4. Hiển thị bản xem trước (dry-run) để người dùng duyệt
5. Thực thi kế hoạch bằng một **workflow engine xác định** (deterministic), có retry, idempotency, resume và trace đầy đủ

Ví dụ: người dùng gõ *"Cuối tuần tổng hợp task đã hoàn thành từ Trello, ghi vào Google Sheet rồi báo cáo lên kênh Slack của team"* — hệ thống tự sinh ra workflow 3 bước, tự map dữ liệu giữa các bước, và thực thi.

### 1.4. Điểm khác biệt cốt lõi

| | Zapier / n8n | Dự án này |
|---|---|---|
| Cách tạo workflow | Kéo-thả thủ công | Mô tả bằng ngôn ngữ tự nhiên |
| Tập tool | Connector do nền tảng viết sẵn | Bất kỳ MCP Server nào người dùng kết nối |
| Nhận biết tool mới | Phải chờ nền tảng hỗ trợ | Tự động discovery qua `tools/list` |
| Logic điều kiện | If-else cấu hình cứng | AI tự suy luận từ ngữ cảnh |

Điểm nhấn quan trọng: hệ thống **không hard-code** bất kỳ tool nào. Thêm một MCP Server mới không yêu cầu sửa code lõi — đây là yếu tố khiến sản phẩm thực sự là một *platform* chứ không phải một ứng dụng đơn lẻ.

### 1.5. Đối chiếu với tiêu chí đánh giá

Dự án được thiết kế bám theo bộ tiêu chí chấm điểm. Bảng dưới đây là kim chỉ nam cho việc phân bổ công sức — mọi quyết định về phạm vi ở mục 7 và lộ trình ở mục 9 đều dựa trên bảng này.

| Tiêu chí | Trọng số | Thành phần đáp ứng | Mục |
|---|---|---|---|
| System Architecture & Problem Formulation | 20% | Kiến trúc 5 lớp, plan-then-execute, đặc tả DSL | 2, 3 |
| Technical Implementation | 25% | Workflow Engine tự xây, MCP Client layer | 5 |
| AI / Algorithmic Component | 20% | Tool Retrieval, Planner, chiến lược replan, thí nghiệm so sánh | 4.1, 5.4, 8.2 |
| Product Quality & Functionality | 15% | Ba màn hình cốt lõi, trải nghiệm end-to-end | 6.2 |
| Demonstration | 10% | Kịch bản demo, màn hình trace real-time, phương án dự phòng | 7.3 |
| Technical Explanation & Defense | 10% | Luận cứ kiến trúc, số liệu đo đạc, câu hỏi phản biện | 8, 10 |

**Hai lưu ý về cân bằng công sức:**

1. **AI/Algorithmic chiếm 20%**, trong khi kiến trúc plan-then-execute lại cố ý thu hẹp vai trò của LLM trong luồng thực thi. Đây là mâu thuẫn cần xử lý có ý thức: phần thuật toán thật sự của dự án phải nằm ở **Tool Retrieval** (mục 4.1), **chiến lược replan** (mục 5.4) và **các thí nghiệm so sánh** (mục 8.2) — không phải ở việc gọi API LLM.

2. **Product Quality + Demonstration cộng lại là 25%**, ngang với Technical Implementation. Frontend vì thế **không phải hạng mục phụ làm cuối cùng**, mà được đưa lên song song với backend trong lộ trình (mục 9).

---

## 2. Kiến trúc hệ thống

### 2.1. Nguyên tắc thiết kế: Plan-then-Execute

Đây là quyết định kiến trúc quan trọng nhất của dự án.

**Không chọn:** Agent loop thuần (kiểu ReAct) — để LLM vừa suy nghĩ vừa gọi tool liên tục trong vòng lặp.
Nhược điểm: không tái lập được kết quả, không resume được khi crash, khó test, tốn token, và khó giải thích vì sao hệ thống hành động như vậy.

**Lựa chọn:** Tách đôi trách nhiệm.

> **LLM chỉ sinh kế hoạch. LLM không thực thi. Engine mới thực thi.**

Lợi ích trực tiếp:

- Kế hoạch là dữ liệu có cấu trúc → **validate được trước khi chạy**
- Người dùng **duyệt được** trước khi có side-effect thật
- Cùng một kế hoạch chạy lại cho **kết quả giống hệt**
- Crash giữa chừng vẫn **resume** được từ bước dở dang
- Trả lời được câu hỏi kinh điển *"làm sao đảm bảo AI không làm bậy?"*

**Ngoại lệ có kiểm soát:** khi một bước lỗi và retry vẫn thất bại, engine có thể đẩy ngữ cảnh lỗi ngược về LLM để sửa kế hoạch rồi chạy tiếp (cơ chế `replan`). Phần thực thi vẫn xác định, nhưng hệ thống có khả năng tự phục hồi.

### 2.2. Sơ đồ các lớp

```
┌─────────────────────────────────────────────────────────┐
│  Người dùng: mô tả công việc bằng ngôn ngữ tự nhiên     │
└────────────────────────┬────────────────────────────────┘
                         ▼
┌─────────────────────────────────────────────────────────┐
│  LỚP 1 — PLANNER                                        │
│  • Tool Retrieval: lọc tool liên quan từ registry       │
│  • LLM sinh Workflow Plan (JSON DSL)                    │
│  • Vòng sửa lỗi khi validate fail (tối đa 3 lần)        │
└────────────────────────┬────────────────────────────────┘
                         ▼
┌─────────────────────────────────────────────────────────┐
│  LỚP 2 — VALIDATOR (3 tầng)                             │
│  • Schema validate: đúng cấu trúc DSL?                  │
│  • Tool & args validate: tool có thật? args khớp?       │
│  • Graph validate: có cycle? reference hợp lệ?          │
└────────────────────────┬────────────────────────────────┘
                         ▼
┌─────────────────────────────────────────────────────────┐
│  LỚP 3 — DRY-RUN & APPROVAL                             │
│  • Chạy thật bước `read`, mô phỏng bước `write`         │
│  • Hiển thị preview, chờ người dùng xác nhận            │
└────────────────────────┬────────────────────────────────┘
                         ▼
┌─────────────────────────────────────────────────────────┐
│  LỚP 4 — WORKFLOW ENGINE  ★ trọng tâm kỹ thuật          │
│  • DAG scheduler (tuần tự + song song)                  │
│  • Retry with exponential backoff                       │
│  • Idempotency guard (chống side-effect trùng lặp)      │
│  • State persistence & resume sau crash                 │
│  • Execution trace từng bước                            │
└────────────────────────┬────────────────────────────────┘
                         ▼
┌─────────────────────────────────────────────────────────┐
│  LỚP 5 — MCP CLIENT LAYER                               │
│  • Quản lý kết nối tới nhiều MCP Server                 │
│  • Tool discovery (`tools/list`) → Tool Registry        │
│  • Tool invocation (`tools/call`)                       │
│  • Credential & connection management                   │
└────────────────────────┬────────────────────────────────┘
                         ▼
        ┌────────────────┼────────────────┐
        ▼                ▼                ▼
   MCP Server A     MCP Server B     MCP Server C
   (Task mgmt)      (GitHub)         (Filesystem)
        │                │                │
        ▼                ▼                ▼
   Trello/Slack     GitHub API      Local files
   Sheets/Calendar
```

### 2.3. Vì sao dùng MCP thay vì tự viết adapter cho từng API

Cần nói chính xác về mặt thuật ngữ, vì đây là chi tiết dễ bị hỏi khi bảo vệ:

- **Tool Calling** là cơ chế ở tầng LLM — model nhận schema và quyết định gọi tool nào. Dùng MCP hay không thì vẫn phải có tool calling.
- **MCP (Model Context Protocol)** là chuẩn ở tầng đóng gói/vận chuyển — quy định cách một tool tự mô tả mình và cách được gọi.
- **API** nằm dưới cùng — bản thân mỗi MCP Server bên trong vẫn đang gọi REST API của dịch vụ tương ứng.

Nói cách khác: dự án **dùng MCP làm chuẩn tích hợp tool, thay vì tự viết adapter riêng cho từng API** — chứ không phải "thay API bằng MCP".

**Quyết định về phạm vi:** hệ thống **chỉ hỗ trợ MCP**, không hỗ trợ cắm REST API thô. Lý do: hỗ trợ OpenAPI spec tuỳ ý đòi hỏi tự viết bộ chuyển đổi schema, xử lý auth đa dạng, phân trang, mã lỗi... — nhân đôi khối lượng công việc mà không tăng giá trị học thuật. Người dùng có API riêng vẫn dùng được thông qua việc bọc nó trong một MCP Server.

---

## 3. Đặc tả Workflow DSL

DSL là "hợp đồng" giữa AI và engine: LLM chỉ được sinh ra đúng cấu trúc này, engine chỉ hiểu đúng cấu trúc này.

### 3.1. Cấu trúc tổng thể

```json
{
  "version": "1.0",
  "workflow_id": "wf_7fa3",
  "name": "Báo cáo tiến độ cuối tuần",
  "source_prompt": "Cuối tuần tổng hợp task đã xong từ Trello, ghi vào Sheet rồi báo Slack",
  "inputs": {
    "board_id": { "type": "string", "required": true },
    "channel":  { "type": "string", "default": "#team" }
  },
  "steps": [ /* ... */ ],
  "outputs": {
    "report_url": "${steps.s2.output.spreadsheet_url}"
  }
}
```

`source_prompt` được giữ lại để phục vụ trace và vòng `replan` (đưa cả prompt gốc lẫn thông tin lỗi về LLM khi cần sửa kế hoạch).

### 3.2. Cấu trúc một Step

```json
{
  "id": "s1",
  "description": "Lấy các task đã hoàn thành trong tuần",
  "tool": {
    "server": "mcp_task_manager",
    "name": "list_cards",
    "args": {
      "board_id": "${inputs.board_id}",
      "list_name": "Done",
      "since": "${runtime.week_start}"
    }
  },
  "depends_on": [],
  "condition": null,
  "retry": {
    "max_attempts": 3,
    "backoff": "exponential",
    "initial_delay_ms": 500
  },
  "idempotency_key": null,
  "side_effect": "read",
  "on_error": "fail"
}
```

### 3.3. Giải thích các trường

**`depends_on`** — biến danh sách bước phẳng thành DAG. Engine dựa vào đây để xác định bước nào có thể chạy song song. Không có trường này thì mất hoàn toàn khả năng parallel execution.

**Biểu thức tham chiếu `${...}`** — cơ chế truyền dữ liệu giữa các bước. Ba namespace:

| Namespace | Ý nghĩa | Ví dụ |
|---|---|---|
| `${inputs.*}` | Tham số đầu vào của workflow | `${inputs.board_id}` |
| `${steps.<id>.output.*}` | Output của bước trước | `${steps.s1.output.cards}` |
| `${runtime.*}` | Giá trị do hệ thống cung cấp | `${runtime.now}`, `${runtime.week_start}` |

Namespace `runtime` tồn tại để **không để LLM tự tính ngày tháng** — đây là nguồn lỗi phổ biến và khó phát hiện.

**`side_effect`** (`read` | `write`) — LLM bắt buộc khai báo bước này có thay đổi dữ liệu bên ngoài không. Engine dùng trường này để thực hiện dry-run: bước `read` chạy thật để lấy dữ liệu preview, bước `write` chỉ hiển thị dự định mà chưa thực thi.

**`idempotency_key`** — bắt buộc với mọi bước `write`. Ví dụ: `"post_report_${runtime.week_start}"`. Engine lưu key đã thực thi thành công vào DB; khi retry hoặc resume sau crash, nếu key đã tồn tại thì bỏ qua — đảm bảo không gửi Slack hai lần, không tạo task trùng.

**`on_error`** — chiến lược xử lý lỗi:

| Giá trị | Hành vi |
|---|---|
| `fail` | Dừng toàn bộ workflow, đánh dấu failed |
| `continue` | Bỏ qua bước này, tiếp tục các bước không phụ thuộc |
| `replan` | Đẩy ngữ cảnh lỗi về LLM để sửa kế hoạch rồi chạy tiếp |

**`condition`** — biểu thức điều kiện đơn giản, ví dụ `"${steps.s1.output.count} > 0"`.

> **Lưu ý bảo mật quan trọng:** phải định nghĩa một grammar hẹp và tự viết parser. Tuyệt đối **không** dùng `eval()` hay bất kỳ cơ chế thực thi động nào trên chuỗi do LLM sinh ra.

### 3.4. Ba tầng validate

Đây là lớp biến "JSON do LLM sinh ra" thành "kế hoạch an toàn để thực thi".

| Tầng | Kiểm tra | Chặn được lỗi gì |
|---|---|---|
| **1. Schema** | JSON đúng cấu trúc DSL, đủ trường bắt buộc, đúng kiểu | LLM sinh sai format |
| **2. Tool & Args** | `server`/`name` có trong Tool Registry; `args` khớp `inputSchema` mà MCP Server khai báo | LLM bịa tool không tồn tại, thiếu tham số bắt buộc, sai kiểu dữ liệu |
| **3. Graph** | DAG không có cycle; mọi `${steps.sX...}` trỏ tới bước thực sự chạy trước | Kế hoạch không thể thực thi, deadlock logic |

Nếu fail ở bất kỳ tầng nào: trả thông tin lỗi cụ thể về LLM để sinh lại, giới hạn tối đa 3 vòng. Quá 3 vòng thì báo lỗi cho người dùng kèm giải thích.

### 3.5. Runtime State (tách biệt với Definition)

DSL ở trên là *định nghĩa*. Khi thực thi, engine tạo một bản ghi trạng thái riêng:

```json
{
  "run_id": "run_91c",
  "workflow_id": "wf_7fa3",
  "status": "running",
  "current_steps": ["s2"],
  "step_states": {
    "s1": {
      "status": "succeeded",
      "attempts": 1,
      "output": { "cards": [ /* ... */ ], "count": 12 },
      "started_at": "2026-09-11T09:00:00Z",
      "ended_at": "2026-09-11T09:00:03Z"
    },
    "s2": {
      "status": "running",
      "attempts": 2,
      "last_error": "429 rate limit"
    }
  }
}
```

Việc tách bạch **definition** và **run state** là điều kiện tiên quyết để có resume sau crash và trace từng bước — hai năng lực mà agent loop thuần không thể cung cấp.

---

## 4. Các thách thức kỹ thuật và hướng xử lý

Đây là phần nên được trình bày kỹ khi bảo vệ, vì nó cho thấy dự án được thiết kế dựa trên hiểu biết về vấn đề thực tế chứ không chỉ ghép thư viện.

### 4.1. Tool Retrieval — thành phần thuật toán trọng tâm

> **Đây là hạng mục AI/Algorithmic chính của dự án (20% điểm), không phải tính năng phụ.** Vì kiến trúc plan-then-execute cố ý giữ LLM ngoài luồng thực thi, phần đóng góp thuật toán thực sự phải nằm ở đây.

**Vấn đề:** khi tool set do mình tự viết, mô tả rõ ràng và nhất quán, LLM chọn đúng khá dễ. Nhưng tool đến từ MCP Server bên thứ ba có thể có mô tả mơ hồ, tên đặt tuỳ tiện, tham số không theo convention nào. Càng nhiều tool "lạ" trong context, độ chính xác càng giảm — đây là nút thắt cổ chai khi hệ thống mở rộng lên hàng chục, hàng trăm tool.

**Pipeline đề xuất (4 giai đoạn):**

| Giai đoạn | Nội dung |
|---|---|
| **1. Indexing** | Khi kết nối MCP Server mới, sinh embedding cho từng tool từ tổ hợp `name + description + tên các tham số`. Lưu vào pgvector. |
| **2. Query expansion** | Mô tả của người dùng thường là một công việc nhiều bước, không khớp trực tiếp với tool nào. Dùng LLM tách thành các sub-intent, embedding từng sub-intent riêng. |
| **3. Hybrid retrieval** | Kết hợp semantic search (vector similarity) với keyword matching (BM25) — vì tên tool thường là từ khoá chính xác mà vector search dễ bỏ sót. |
| **4. Re-ranking** | Gộp kết quả, loại trùng, chọn top-K cuối cùng đưa vào context planner. |

> **Trong phạm vi 6 tuần:** chỉ làm giai đoạn 1, 2 và 4. Giai đoạn 3 (hybrid với BM25) bị cắt — xem `docs/KE-HOACH-6-TUAN.md` mục 2. Phần mô tả dưới đây giữ nguyên vì nó là thiết kế đầy đủ, dùng cho phần "hướng phát triển" trong báo cáo.

**Các biến thể cần so sánh và đo đạc** (đây là phần tạo ra số liệu cho báo cáo):

- Baseline: đưa toàn bộ tool vào context (không retrieval)
- Chỉ semantic search, không query expansion
- Semantic + query expansion
- Hybrid (semantic + BM25) + query expansion
- Khảo sát ảnh hưởng của K (5 / 10 / 20 tool)

**Chỉ số đo:** Recall@K (tool đúng có nằm trong top-K không), độ chính xác chọn tool cuối cùng, số token tiết kiệm được, và độ trễ tăng thêm.

**Tình huống khó cần xử lý riêng:** nhiều tool gần giống nhau (ví dụ `create_card` của Trello và `create_issue` của GitHub đều là "tạo task mới"). Cần bổ sung ngữ cảnh về nguồn server vào embedding, và cho phép planner hỏi lại người dùng khi độ tin cậy thấp.

### 4.2. Data flow giữa các bước

**Vấn đề:** đây là điểm khó nhất, khó hơn cả việc chọn đúng tool. Output của tool A phải map vào đúng tham số của tool B, trong khi schema của cả hai đều do bên thứ ba định nghĩa. Chuỗi càng dài, xác suất sai càng nhân lên — mỗi bước đúng 90% thì 5 bước chỉ còn khoảng 59%.

**Hướng xử lý:**
- Bắt buộc mọi tham chiếu dữ liệu phải qua cú pháp `${...}` có cấu trúc, không cho LLM tự "điền giá trị nghĩ ra"
- Tầng validate 3 kiểm tra mọi reference có trỏ tới bước hợp lệ
- Khi bước trước đã chạy xong, engine kiểm tra kiểu dữ liệu thực tế trước khi gán vào bước sau; sai kiểu → `replan`

### 4.3. Bảo mật: Tool Poisoning

**Vấn đề:** cho phép người dùng kết nối MCP Server tuỳ ý nghĩa là hệ thống sẽ đọc và hành động theo mô tả tool do bên thứ ba viết. Một MCP Server độc hại (hoặc bị chiếm quyền) có thể nhét chỉ thị ẩn vào phần mô tả tool hoặc vào kết quả trả về, nhằm điều khiển agent làm việc ngoài ý muốn người dùng.

**Hướng xử lý ở quy mô đồ án:**
- Allow-list: chỉ cho kết nối MCP Server đã được duyệt, không mở tự do
- Bước xác nhận bắt buộc (dry-run approval) trước mọi hành động `write`
- Coi mô tả tool và kết quả trả về là **dữ liệu**, không phải chỉ thị — tách bạch rõ trong prompt template
- Giới hạn quyền: mỗi kết nối chỉ được cấp scope tối thiểu cần thiết

### 4.4. Quản lý kết nối và thông tin xác thực

**Vấn đề:** mỗi MCP Server có cơ chế xác thực khác nhau (API key, OAuth, token). Cần lưu trữ credential theo từng người dùng một cách an toàn.

**Hướng xử lý:** một `ConnectionManager` chịu trách nhiệm lifecycle của kết nối (connect, health check, reconnect, disconnect); credential mã hoá khi lưu, không bao giờ đưa vào prompt của LLM.

### 4.5. Độ tin cậy khi thực thi

**Vấn đề:** một workflow gọi nhiều API thật có rất nhiều điểm có thể hỏng: rate limit, timeout, service down, crash giữa chừng.

**Hướng xử lý:** đây chính là lý do tồn tại của workflow engine tự viết — retry with backoff, idempotency guard, state persistence, resume. Chi tiết ở mục 5.

---

## 5. Workflow Engine — trọng tâm kỹ thuật

Phần gọi LLM và phần giao tiếp MCP đều đã có SDK hỗ trợ sẵn. Workflow Engine là phần code thật sự tự xây, và là nơi thể hiện năng lực backend rõ nhất.

### 5.1. Phạm vi

Engine này **không** nhằm thay thế Temporal, Inngest hay Trigger.dev. Mục tiêu là một engine tối giản nhưng làm *đúng* những việc cốt lõi:

| Năng lực | Mô tả |
|---|---|
| **DAG Scheduling** | Xác định thứ tự thực thi từ `depends_on`; các bước độc lập chạy song song |
| **Retry** | Exponential backoff, giới hạn số lần, phân biệt lỗi tạm thời (429, 503) và lỗi vĩnh viễn (400, 404) |
| **Idempotency** | Lưu key đã thực thi thành công; retry/resume không tạo side-effect trùng lặp |
| **State Persistence** | Mọi chuyển trạng thái được ghi xuống DB ngay, không giữ trong memory |
| **Resume** | Khởi động lại sau crash, đọc run state từ DB và tiếp tục từ bước dở dang |
| **Execution Trace** | Log đầy đủ: bước nào, tool nào, args gì, kết quả gì, mất bao lâu, retry mấy lần |

### 5.2. Vòng đời một Run

```
PENDING ──► VALIDATING ──► AWAITING_APPROVAL ──► RUNNING ──┬─► SUCCEEDED
               │                   │                        │
               ▼                   ▼                        ├─► FAILED
          REJECTED             CANCELLED                    │
                                                            └─► REPLANNING ──┐
                                                                     ▲       │
                                                                     └───────┘
```

### 5.3. Vì sao tự viết thay vì dùng engine có sẵn

Trong đề cương nên nêu rõ nhận thức về trade-off: Temporal (có SDK TypeScript), Inngest hay Trigger.dev là lựa chọn đúng cho môi trường production. Việc tự viết ở đây có hai lý do chính đáng:

1. Đề bài chỉ định rõ **Workflow Engine** là một thành phần công nghệ cần có — nếu để AI tự điều phối hoàn toàn thì thành phần này biến mất khỏi dự án
2. Đây là phần duy nhất trong hệ thống thể hiện được kỹ năng thiết kế hệ thống phân tán ở mức code thật

Việc chủ động nêu ra rằng "ở production có thể thay bằng Temporal" thể hiện hiểu biết về hệ sinh thái, không phải điểm yếu.

### 5.4. Chiến lược Replan — thuật toán tự phục hồi

Đây là hạng mục thuật toán thứ hai của dự án (bên cạnh Tool Retrieval ở mục 4.1). `replan` không phải là "ném lỗi về cho LLM rồi hy vọng", mà là một quy trình phân loại lỗi và chọn chiến lược tương ứng.

**Bước 1 — Phân loại lỗi:**

| Loại lỗi | Ví dụ | Chiến lược |
|---|---|---|
| Tạm thời | 429, 503, timeout | Không replan — để retry xử lý |
| Sai tham số | 400, validation error từ server | Replan cục bộ: chỉ sửa `args` của bước lỗi |
| Sai tool | 404, tool không tồn tại / không phù hợp | Replan cục bộ: chọn tool khác cho cùng mục tiêu bước |
| Sai giả định dữ liệu | Output bước trước rỗng hoặc khác kiểu dự kiến | Replan một phần: sinh lại các bước từ bước lỗi trở đi |
| Sai kế hoạch tổng thể | Nhiều bước liên tiếp thất bại | Replan toàn bộ, hoặc dừng và hỏi lại người dùng |

**Bước 2 — Replan cục bộ trước, toàn cục sau.** Nguyên tắc: giữ lại tối đa phần kế hoạch đã chạy thành công. Chỉ sinh lại phần nhỏ nhất cần thiết. Điều này vừa tiết kiệm token, vừa tránh làm hỏng các bước `write` đã hoàn tất.

**Bước 3 — Ngữ cảnh đưa vào LLM khi replan:** `source_prompt` gốc, kế hoạch hiện tại, bước bị lỗi, thông báo lỗi thực tế, output của các bước đã chạy, và danh sách các phương án đã thử thất bại (để không lặp lại cùng một sai lầm).

**Giới hạn:** tối đa 2 vòng replan cho mỗi run. Vượt quá thì dừng và báo người dùng — tránh vòng lặp vô hạn đốt token.

**Chỉ số đo:** tỷ lệ phục hồi thành công theo từng loại lỗi, số vòng replan trung bình, so sánh completion rate khi bật và tắt replan.

---

## 6. Tech Stack và thiết kế sản phẩm

### 6.1. Tech Stack

| Lớp | Công nghệ | Vai trò |
|---|---|---|
| **Ngôn ngữ** | TypeScript (Node.js 22 LTS) | Dùng chung cho toàn hệ thống |
| **Frontend** | Next.js + React | Ba màn hình cốt lõi (mục 6.2) |
| **Backend API** | NestJS *(hoặc Next.js API routes)* | REST API, WebSocket cho trace real-time |
| **MCP** | MCP TypeScript SDK | Client layer — kết nối, discovery, invocation |
| **LLM** | Claude API (structured output) | Planner và replan |
| **Schema & Validation** | **Zod** | ★ Nguồn sự thật duy nhất cho Workflow DSL |
| **Vector store** | pgvector | Tool Retrieval (mục 4.1) — dùng chung PostgreSQL |
| **Embedding** | API embedding của nhà cung cấp LLM | Sinh vector cho tool description |
| **Keyword search** | PostgreSQL full-text search | Thành phần BM25 — *ngoài phạm vi 6 tuần* |
| **Database** | PostgreSQL 16 | Workflow definition, run state, idempotency key, trace |
| **ORM / Migration** | Prisma hoặc Drizzle | |
| **Queue / Background** | BullMQ + Redis | ★ Lớp chạy nền bên dưới engine — **không phải** engine |
| **Testing** | Vitest + Testcontainers | Test engine với PostgreSQL và Redis thật |
| **Triển khai** | Docker Compose | Một môi trường dev, một môi trường demo |

### 6.1.1. Ba quyết định cần giải thích khi bảo vệ

**Vì sao Zod là trung tâm.** Workflow DSL xuất hiện ở bốn nơi: planner sinh ra nó, validator kiểm tra nó, engine thực thi nó, frontend vẽ sơ đồ từ nó. Với Zod, DSL được định nghĩa **một lần duy nhất** và cho ra cả bốn thứ cần thiết: runtime validation (tầng 1 ở mục 3.4), TypeScript type cho backend, type dùng chung cho frontend, và JSON Schema xuất thẳng cho LLM structured output. Sửa DSL ở một chỗ, mọi nơi cập nhật theo, sai lệch bị compiler bắt ngay. Đây là lý do kỹ thuật chính khiến TypeScript được chọn — DSL là tài sản trung tâm và nó được dùng ở cả hai đầu của hệ thống.

**BullMQ không phải Workflow Engine.** Đây là điểm dễ bị hiểu nhầm và cần nói rõ. BullMQ cung cấp hàng đợi công việc, chạy nền, và retry ở mức job. Nó **không** cung cấp: DAG scheduling theo `depends_on`, resolve biểu thức `${steps.sX.output...}` giữa các bước, idempotency ở tầng nghiệp vụ, state machine của cả run, resume đúng bước dở dang, hay trace có ngữ nghĩa. Toàn bộ những thứ đó vẫn phải tự xây — chúng chính là nội dung của mục 5 và là phần chấm điểm Technical Implementation. BullMQ chỉ thay thế phần *hạ tầng chạy nền*, không thay thế phần *logic điều phối*.

**Vì sao không dùng Java/Spring AI.** Java mạnh hơn ở mô hình transaction chín muồi và ở việc Spring AI cho sẵn Micrometer/OpenTelemetry (trace gần như miễn phí). Nhưng cả hai là tiện lợi, không phải điều kiện cần: resume và idempotency về bản chất dựa trên trạng thái lưu trong PostgreSQL, nên tính đúng đắn do database đảm bảo chứ không do runtime. Đổi lại, TypeScript cho một codebase duy nhất (không có lớp tích hợp giữa hai service), MCP SDK ở bản tham chiếu, và lợi ích Zod nêu trên. Workload của hệ thống là I/O-bound thuần — chờ MCP Server và LLM — nên Node phù hợp; lợi thế concurrency của Java chỉ có ý nghĩa ở quy mô lớn hơn nhiều.

### 6.1.2. Phân công nhóm

Nhóm 2 người, một codebase, chia theo **module** chứ không theo tầng — để tránh tình trạng một người phải chờ người kia.

| Thành viên | Phụ trách | Ước lượng công sức |
|---|---|---|
| **Người A** | Workflow Engine (mục 5), state persistence, retry, idempotency, resume, BullMQ integration, REST API + WebSocket | ~45% |
| **Người B** | Ba màn hình frontend (mục 6.2), sơ đồ DAG, MCP Server tự viết cho domain quản lý task, chuẩn bị demo và video backup | ~40% |
| **Cùng làm** | Workflow DSL bằng Zod (chốt sớm, cả hai cùng dùng), Planner + Tool Retrieval, thí nghiệm và đo đạc (mục 8.2) | ~15% |

**Nguyên tắc phối hợp:**

1. **Chốt Zod schema của DSL trong tuần đầu tiên.** Đây là mặt tiếp giáp giữa hai người. Khi schema đã có, người B dựng được frontend với dữ liệu giả mà không cần chờ engine chạy xong.
2. **Chốt sớm định dạng message WebSocket** cho trace real-time — đây là mặt tiếp giáp thứ hai.
3. **Người viết MCP Server nên hiểu rõ Tool Registry**, vì `tools/list` là chỗ hai phần gặp nhau. Hai người nên thống nhất tool schema mẫu trước khi ai bắt tay code.

### 6.2. Ba màn hình cốt lõi

> **Product Quality (15%) + Demonstration (10%) = 25%**, ngang với Technical Implementation. Frontend vì thế được coi là hạng mục chính, không phải phần làm nốt ở cuối. Nguyên tắc: **backend tốt đến mấy mà người chấm không nhìn thấy thì không tính điểm** — ba màn hình dưới đây chính là nơi biến năng lực kỹ thuật thành thứ quan sát được.

> **Khuyến nghị từ vòng rà soát cuối:** gộp màn hình 1 và 2 thành một màn hình có hai trạng thái ("kế hoạch" và "đã chạy thử, chờ duyệt"). Người dùng hiện phải đọc cùng một kế hoạch hai lần. Xem `docs/AUDIT.md` phần II mục 3. Đặc tả dưới đây giữ nguyên vì nội dung từng phần không đổi — chỉ là hợp vào một trang.

**Màn hình 1 — Nhập mô tả và xem kế hoạch**

- Ô nhập mô tả bằng ngôn ngữ tự nhiên, có sẵn vài ví dụ mẫu
- Hiển thị kế hoạch sinh ra dưới dạng **sơ đồ DAG trực quan**, không phải JSON thô
- Mỗi node cho thấy: tool nào, server nào, tham số gì, đọc hay ghi
- Các nhánh song song hiển thị rõ ràng — đây là cách thể hiện trực quan năng lực DAG scheduling của engine
- Cho phép sửa tay tham số trước khi chạy

**Màn hình 2 — Duyệt dry-run**

- Phân tách rõ: bước `read` đã chạy (kèm dữ liệu thật lấy về) và bước `write` **sẽ** thực hiện
- Với mỗi bước ghi, hiển thị cụ thể "sẽ tạo task tên X trong board Y", "sẽ gửi tin nhắn nội dung Z vào kênh W"
- Nút duyệt / từ chối / sửa lại
- Đây là màn hình trả lời trực quan cho câu hỏi phản biện *"làm sao đảm bảo AI không làm bậy?"*

**Màn hình 3 — Trace thực thi real-time** *(quan trọng nhất cho điểm Demonstration)*

- Timeline từng bước, cập nhật trực tiếp qua WebSocket/SSE khi engine chạy
- Mỗi bước hiển thị: trạng thái, số lần retry, thời gian thực thi, args gửi đi, kết quả trả về
- Hiển thị rõ khi retry xảy ra và vì sao (ví dụ: *"lần 2/3 — lỗi 429 rate limit, chờ 1s"*)
- Hiển thị rõ khi replan kích hoạt và kế hoạch thay đổi thế nào
- Cho phép xem lại trace của các run cũ

Màn hình 3 là thứ khiến toàn bộ công sức xây engine trở nên **nhìn thấy được**. Không có nó, retry / idempotency / resume chỉ tồn tại trong code và log — hội đồng không có cách nào cảm nhận được.

### 6.3. Màn hình phụ

- Quản lý kết nối MCP Server: thêm/xoá server, xem danh sách tool đã discovery, kiểm tra trạng thái kết nối
- Lịch sử các run đã chạy

---

## 7. Phạm vi dự án

### 7.1. Trong phạm vi

**Backend / Engine**
- Kết nối và quản lý nhiều MCP Server, tool discovery tự động qua `tools/list`
- Workflow Engine: DAG scheduling, retry, idempotency, state persistence, resume, trace
- Ba tầng validate + vòng sửa lỗi
- Dry-run và cơ chế duyệt

**AI / Algorithmic**
- Tool Retrieval pipeline đầy đủ 4 giai đoạn (mục 4.1) — **bắt buộc, không phải tuỳ chọn**
- Planner sinh Workflow DSL từ ngôn ngữ tự nhiên
- Chiến lược replan có phân loại lỗi (mục 5.4)
- Thí nghiệm so sánh các biến thể retrieval và planning, có số liệu

**Frontend**
- Ba màn hình cốt lõi ở mục 6.2, trong đó màn hình trace real-time là bắt buộc
- Hai màn hình phụ ở mục 6.3

### 7.2. Ngoài phạm vi (ranh giới rõ ràng)

Đây là phần quan trọng để tránh phình phạm vi — nên ghi rõ trong đề cương:

- **Không** hỗ trợ cắm REST API thô / OpenAPI spec (chỉ MCP)
- **Không** làm giao diện kéo-thả để thiết kế workflow thủ công
- **Không** hỗ trợ multi-tenant / multi-workspace (một workspace demo là đủ)
- **Không** làm marketplace hay hệ thống chia sẻ workflow
- **Không** hỗ trợ trigger tự động theo lịch hay webhook ở giai đoạn đầu (chạy theo yêu cầu người dùng)
- **Không** tự xây LLM hay fine-tune model
- **Không** làm rollback / compensating transaction cho bước đã ghi — dùng dry-run để phòng ngừa thay vì khắc phục

### 7.3. Demo scenario

Để chứng minh tính chất "platform", demo sẽ kết nối **3 MCP Server thuộc các domain khác nhau**:

1. **MCP Server tự viết** — domain quản lý task nhóm dự án (Trello, Slack, Google Sheets, Google Calendar)
2. **MCP Server công khai** — GitHub *(mục tiêu phụ trong phạm vi 6 tuần)*
3. **MCP Server công khai** — Filesystem

**Kịch bản demo chính (theo thứ tự, khoảng 8-10 phút):**

1. **Workflow cơ bản** — mô tả một việc 3 bước, xem kế hoạch dạng sơ đồ, duyệt dry-run, theo dõi trace chạy xong. Chứng minh luồng end-to-end hoạt động.
2. **Nhánh song song** — một workflow có 2 nhánh độc lập, cho thấy chúng chạy đồng thời trên màn hình trace. Chứng minh DAG scheduling.
3. **Chủ động gây lỗi** — ngắt một MCP Server giữa chừng, cho hội đồng thấy retry đếm lên, rồi replan kích hoạt và kế hoạch tự sửa. Đây là phần ấn tượng nhất, và là bằng chứng sống cho toàn bộ phần reliability.
4. **Cắm MCP Server mới ngay tại chỗ** — thêm một server chưa từng dùng, không sửa dòng code lõi nào, rồi ra lệnh sử dụng tool của nó. Đây là bằng chứng cho tính chất "platform".

**Phương án dự phòng (bắt buộc chuẩn bị):**

Demo phụ thuộc mạng và API bên ngoài nên rủi ro cao. Với 10% điểm, cần có:

- **Video quay sẵn** toàn bộ kịch bản, chất lượng tốt, có thể chiếu thay nếu demo live hỏng
- **MCP Server chạy local** (filesystem) làm phương án thay thế nếu mất mạng hoặc dịch vụ ngoài lỗi
- **Chế độ mock** cho LLM: cache sẵn kế hoạch của các prompt demo, bật lên khi API LLM chậm hoặc lỗi
- Dữ liệu demo đã chuẩn bị sẵn trong board/sheet, không tạo mới tại chỗ

---

## 8. Tiêu chí đánh giá và số liệu

Dự án nên có phần đánh giá định lượng — đây là điểm cộng đáng kể so với các đồ án chỉ "chạy được là xong".

### 8.1. Các chỉ số đề xuất

| Chỉ số | Cách đo | Ý nghĩa |
|---|---|---|
| **Plan validity rate** | % kế hoạch pass cả 3 tầng validate ngay lần sinh đầu tiên | Chất lượng của planner + prompt |
| **Số vòng sửa trung bình** | Trung bình số lần phải trả lỗi về LLM | Độ ổn định của output |
| **Tool selection accuracy** | So với kế hoạch chuẩn do người đánh giá | Hiệu quả của tool retrieval |
| **Workflow completion rate** | % workflow chạy đến `SUCCEEDED` | Độ tin cậy tổng thể |
| **Recovery success rate** | % workflow phục hồi thành công sau khi inject lỗi | Hiệu quả của retry + replan |
| **Latency** | Thời gian từ prompt tới kế hoạch; tổng thời gian thực thi | Tính khả dụng thực tế |

### 8.2. Thí nghiệm bắt buộc

> Ba thí nghiệm dưới đây là **phần đóng góp học thuật của dự án**, phục vụ trực tiếp tiêu chí AI/Algorithmic (20%) và Technical Defense (10%). Không nên coi là phần làm thêm nếu còn thời gian.

**Thí nghiệm 1 — Hiệu quả Tool Retrieval.** So sánh 3 cấu hình: baseline không retrieval / semantic thuần / semantic + query expansion. Đo Recall@K, tool selection accuracy, số token tiêu thụ, độ trễ.

Về quy mô tool set: với hai MCP Server trong phạm vi 6 tuần, danh mục thật chỉ khoảng 20 tool. Để cho thấy retrieval càng cần thiết khi hệ thống mở rộng, bổ sung **tool tổng hợp làm nhiễu** — nhân bản tool có sẵn với tên và mô tả biến thể — để đạt ba mốc 10 / 20 / 50 tool. Việc dùng tool tổng hợp phải **nói rõ trong báo cáo**; đây là cách hợp lệ để đo Recall@K, nhưng giấu đi thì thành điểm yếu khi bị hỏi.

**Thí nghiệm 2 — So sánh chiến lược planning.** Sinh kế hoạch một lần (one-shot) so với sinh từng bước có phản hồi (incremental). Đo plan validity rate, completion rate, độ trễ và chi phí token. Kết luận nên nêu rõ trade-off giữa độ chính xác và chi phí.

**Thí nghiệm 3 — Chaos test và khả năng phục hồi.** Chủ động inject lỗi theo từng loại đã phân loại ở mục 5.4: ngắt kết nối MCP Server giữa chừng, giả lập 429, trả sai schema, kill process khi đang chạy. Đo recovery success rate theo từng loại lỗi, và so sánh completion rate khi bật/tắt replan. Đồng thời chứng minh idempotency hoạt động đúng (không có side-effect trùng lặp sau resume).

### 8.3. Bộ test case

Xây khoảng 20-30 workflow mẫu ở nhiều mức độ phức tạp:
- Đơn giản: 1-2 bước, tuần tự
- Trung bình: 3-5 bước, có phụ thuộc dữ liệu
- Phức tạp: có nhánh song song, có điều kiện, có bước `write` cần idempotency

---

## 9. Lộ trình triển khai

> Mục này mô tả **thứ tự công việc và lý do**. Lịch cụ thể theo tuần nằm ở `docs/KE-HOACH-6-TUAN.md` — đó mới là bản kế hoạch thi hành, và nó đã cắt bớt phạm vi cho vừa 6 tuần. Khi hai bên khác nhau, lấy bản kế hoạch 6 tuần làm chuẩn.

### 9.1. Phân bổ công sức

Dựa trên trọng số chấm điểm ở mục 1.5:

| Hạng mục | % công sức | Tiêu chí phục vụ |
|---|---|---|
| Workflow Engine + kiến trúc | 30% | Architecture (20%) + Technical Implementation (25%) |
| Planner + Tool Retrieval + thí nghiệm | 25% | AI/Algorithmic (20%) |
| Frontend (3 màn hình cốt lõi) | 20% | Product Quality (15%) + Demonstration (10%) |
| MCP layer + tích hợp | 15% | Technical Implementation |
| Tài liệu, số liệu, chuẩn bị bảo vệ | 10% | Defense (10%) |

Lưu ý: đây là phân bổ **công sức**, không phải thời gian tuần tự — frontend và backend chạy song song từ giai đoạn 4.

### 9.2. Các giai đoạn

| Giai đoạn | Nội dung | Kết quả bàn giao |
|---|---|---|
| **1. Nền tảng** | MCP Client layer, Connection Manager, Tool Registry, tool discovery | Kết nối được MCP Server, liệt kê được tool |
| **2. Engine lõi** | Định nghĩa DSL, DAG scheduler, state persistence, retry, idempotency | Chạy được workflow viết tay bằng JSON |
| **3. Planner** | Prompt engineering, structured output, 3 tầng validate, vòng sửa lỗi | Sinh được kế hoạch từ ngôn ngữ tự nhiên |
| **4. An toàn + Frontend khởi động** ⟵ *bắt đầu song song* | Dry-run, approval flow, execution trace, resume sau crash — **đồng thời** dựng khung frontend và màn hình trace | Luồng hoàn chỉnh có kiểm soát, nhìn thấy được trên giao diện |
| **5. Tool Retrieval + Replan** | Pipeline retrieval 4 giai đoạn, chiến lược replan phân loại lỗi — **đồng thời** hoàn thiện màn hình 1 và 2 | Xử lý được nhiều tool, tự phục hồi, giao diện đủ 3 màn hình |
| **6. Thí nghiệm + đánh giá** | Bộ test case, chạy 3 thí nghiệm ở mục 8.2, thu thập số liệu | Số liệu định lượng cho báo cáo |
| **7. Hoàn thiện demo** | Đánh bóng giao diện, quay video backup, dựng chế độ mock, tập bảo vệ | Demo sẵn sàng + phương án dự phòng |

### 9.3. Hai nguyên tắc về thứ tự

**Engine xây trước Planner.** Engine có thể test độc lập bằng workflow JSON viết tay, không phụ thuộc chất lượng LLM. Nếu làm ngược lại, khi có lỗi sẽ rất khó xác định là do planner sinh sai hay do engine chạy sai.

**Frontend bắt đầu từ giai đoạn 4, không để cuối.** Đây là điều chỉnh quan trọng so với cách làm thông thường. Lý do: Product Quality và Demonstration cộng lại chiếm 25% — nếu frontend bị dồn vào cuối kỳ, nó sẽ là thứ đầu tiên bị cắt khi thiếu thời gian, và mất trắng một phần tư số điểm. Màn hình trace nên được dựng ngay khi engine có trace API, vì nó còn giúp chính bạn debug engine nhanh hơn nhiều so với đọc log.

### 9.4. Thứ tự ưu tiên khi thiếu thời gian

Nếu đến gần deadline mà chưa xong hết, cắt theo thứ tự này (cắt từ trên xuống):

1. Màn hình phụ (quản lý kết nối, lịch sử run) — gộp tạm vào màn hình chính
2. Các biến thể retrieval trong thí nghiệm 1 — giữ lại ít nhất baseline vs semantic
3. Cơ chế `replan` toàn cục — giữ replan cục bộ là đủ
4. Thực thi song song — chạy tuần tự vẫn hoạt động

**Tuyệt đối không cắt:** ba màn hình cốt lõi, Tool Retrieval cơ bản, retry + idempotency, và video demo dự phòng.

---

## 10. Các câu hỏi phản biện dự kiến và cách trả lời

**"Dự án này khác gì Zapier AI hay n8n?"**
Zapier/n8n dùng connector do nền tảng viết sẵn và hỗ trợ thêm tool theo lộ trình của họ. Hệ thống này không hard-code bất kỳ tool nào — bất kỳ MCP Server nào cũng kết nối được và dùng được ngay, không cần sửa code lõi. Có thể demo trực tiếp bằng cách thêm một server mới tại chỗ.

**"Làm sao đảm bảo AI không làm sai, gây hậu quả thật?"**
AI không thực thi. AI chỉ sinh kế hoạch dạng dữ liệu có cấu trúc. Kế hoạch phải qua 3 tầng validate, rồi qua dry-run cho người dùng duyệt, rồi mới được engine thực thi. Mọi bước có side-effect đều có idempotency key.

**"Sao không dùng Temporal / Inngest có sẵn?"**
Có biết và đó là lựa chọn đúng cho production. Ở đây tự xây vì Workflow Engine là thành phần được chỉ định của đề tài, và là phần thể hiện năng lực thiết kế hệ thống. Engine tự xây tập trung vào đúng các năng lực cốt lõi, không nhằm thay thế các giải pháp công nghiệp.

**"Đã dùng BullMQ rồi thì engine còn làm gì nữa?"**
BullMQ là hàng đợi công việc, giải quyết phần chạy nền và retry ở mức job. Nó không biết gì về DAG, về việc resolve dữ liệu giữa các bước, về idempotency ở tầng nghiệp vụ, về state machine của cả run, hay về resume đúng bước dở dang. Toàn bộ những phần đó là engine tự xây, đặt bên trên BullMQ. Có thể minh hoạ bằng bảng đối chiếu ở mục 6.1.1.

**"Nếu LLM sinh kế hoạch sai thì sao?"**
Có ba lớp phòng vệ: validate chặn kế hoạch không hợp lệ trước khi chạy; dry-run cho người dùng phát hiện sai sót về mặt ý định; `replan` xử lý lỗi phát sinh trong lúc chạy. Ngoài ra có số liệu đo plan validity rate để chứng minh mức độ ổn định.

**"Cho cắm MCP Server tuỳ ý thì bảo mật thế nào?"**
Có allow-list, có approval bắt buộc trước hành động `write`, coi mô tả tool là dữ liệu chứ không phải chỉ thị, và giới hạn scope quyền theo từng kết nối. Đây là rủi ro tool poisoning đã biết trong hệ sinh thái MCP và được xử lý có ý thức chứ không bỏ qua.

**"Nếu AI chỉ sinh kế hoạch rồi engine chạy, thì phần AI của đồ án nằm ở đâu?"**
Phần AI nằm ở ba chỗ có thuật toán thật, không phải ở việc gọi API LLM: (1) pipeline Tool Retrieval với query expansion và semantic search — giải bài toán chọn đúng tool khi có hàng chục tool từ nhiều nguồn; (2) chiến lược replan có phân loại lỗi và replan cục bộ trước toàn cục; (3) các thí nghiệm so sánh có số liệu về retrieval và chiến lược planning. Việc tách AI khỏi luồng thực thi là quyết định kiến trúc để đảm bảo độ tin cậy, không phải để giảm vai trò của AI.

**"Điểm mới về mặt kỹ thuật nằm ở đâu?"**
Không nằm ở việc gọi được tool — phần đó SDK đã hỗ trợ. Điểm nhấn nằm ở lớp reliability: biến output không xác định của LLM thành quy trình thực thi xác định, có thể validate, tái lập, phục hồi và truy vết được.

---

## 11. Tóm tắt

Dự án xây dựng một nền tảng cho phép người dùng tự động hoá quy trình công việc bằng cách mô tả bằng ngôn ngữ tự nhiên, với hai đặc điểm kiến trúc cốt lõi:

1. **Tính mở** — không hard-code tool; bất kỳ MCP Server nào cũng tích hợp được, hệ thống tự nhận biết và biết cách sử dụng
2. **Tính tin cậy** — kiến trúc plan-then-execute tách bạch phần suy luận của AI khỏi phần thực thi, cho phép validate, duyệt trước, tái lập, phục hồi và truy vết

Trọng tâm kỹ thuật nằm ở Workflow Engine tự xây và lớp đảm bảo độ tin cậy — cũng chính là phần thể hiện rõ nhất năng lực backend engineering.
