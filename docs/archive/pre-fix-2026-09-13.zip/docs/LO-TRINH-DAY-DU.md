# Lộ trình triển khai đầy đủ

Tiếp nối sau khi hoàn thành kế hoạch 6 tuần. Tài liệu này trả lời: nếu muốn biến đồ án thành một hệ thống thật sự vận hành được, còn phải làm gì.

---

## 0. Thay đổi về bản chất

Đồ án và sản phẩm khác nhau ở chỗ nào:

| | Đồ án (6 tuần) | Hệ thống thật |
|---|---|---|
| Mục tiêu | Chứng minh khái niệm khả thi | Chạy đúng khi không ai nhìn |
| Người dùng | Chính bạn, lúc demo | Người lạ, lúc 3 giờ sáng |
| Lỗi | Thử lại là xong | Có người mất dữ liệu thật |
| Thành công | Hội đồng gật đầu | Không ai phải gọi hỗ trợ |

Hệ quả cụ thể: phần lớn công việc phía trước **không phải tính năng mới**, mà là quản trị, vận hành và độ bền. Đây cũng chính là lý do phần lớn dự án agent thất bại trước khi lên production — thiếu danh mục rõ ràng về việc agent được phép làm gì, không truy vết được hành động đã thực hiện, không theo dõi được sự trôi lệch hành vi. Nội dung giai đoạn 3 dưới đây chủ yếu nhằm vào đúng nhóm vấn đề đó.

**Một lưu ý thẳng thắn về quy mô.** Cạnh tranh trực diện với Zapier hay n8n là việc của một công ty, không phải của hai người. Lộ trình này hướng tới một mục tiêu thực tế hơn: một hệ thống đủ tốt để **bạn và một nhóm nhỏ dùng thật hàng ngày**, có thể mở cho vài chục người dùng, và là nền tảng để quyết định có đi xa hơn hay không. Giai đoạn 4 đánh dấu rõ chỗ cần đội ngũ.

---

## Giai đoạn 2 — Hoàn thiện phần đã cắt

**Khoảng 6-8 tuần · 2 người**

Khôi phục những gì đã cắt trong kế hoạch 6 tuần, cộng thêm những thứ đồ án bỏ qua được nhưng sản phẩm thì không.

### 2.1. Khôi phục từ danh sách cắt

| Hạng mục | Ghi chú triển khai |
|---|---|
| Thực thi song song (FR-EXE-11) | Giới hạn số lời gọi đồng thời theo từng MCP Server để không tự gây rate limit |
| Replan toàn cục và một phần | Bổ sung hai nhánh còn lại của bảng phân loại lỗi |
| Sửa tham số trước khi duyệt | Kèm validate lại, tạo version mới `origin = manual_edit` |
| Chạy lại workflow đã lưu | Cần giải quyết vấn đề idempotency — xem 2.4 |
| Thí nghiệm so sánh chiến lược planning | Giờ thành công cụ tinh chỉnh liên tục, không còn là bài tập một lần |

### 2.2. Xác thực và quyền thật sự

Đồ án chỉ cần đăng nhập cơ bản. Sản phẩm cần:

- OAuth cho từng MCP Server, **theo từng người dùng** — đây là phần nặng nhất của giai đoạn này. Mỗi dịch vụ một luồng OAuth riêng, token phải tự làm mới, thu hồi được, và lưu mã hoá.
- Quyền theo scope: một kết nối chỉ được cấp đúng quyền tối thiểu cần thiết
- Phiên đăng nhập, refresh token, đăng xuất mọi thiết bị

Đây là phần mà đồ án né được nhưng sản phẩm thì không. Nếu người dùng phải dán API key thủ công vào ô cấu hình, hệ thống không dùng được cho ai ngoài dân kỹ thuật.

### 2.3. Xử lý lỗi ở mức sản phẩm

- Phân loại lỗi chi tiết hơn 5 loại hiện có, đặc biệt tách lỗi mạng khỏi lỗi dịch vụ
- Circuit breaker: một MCP Server hỏng liên tục thì ngừng gọi tạm thời thay vì retry vô ích
- Dead letter queue cho run không cứu được, kèm giao diện xem lại
- Thông báo cho người dùng khi run thất bại — hiện tại họ phải tự vào xem

### 2.4. Idempotency ở quy mô thật

Quyết định `(user_id, key)` trong `DATABASE.md` đúng cho đồ án nhưng sẽ gây khó chịu khi dùng thật: người dùng muốn chạy lại một workflow ngay bây giờ mà bị chặn vì key trùng.

Hướng xử lý:
- Thêm TTL cho `idempotency_records` — ví dụ 24 giờ, sau đó key được dùng lại
- Cho phép người dùng chủ động "chạy lại, bỏ qua kiểm tra trùng" với cảnh báo rõ ràng
- Phân biệt "chạy lại vì lỗi" (giữ nguyên key) và "chạy lại có chủ đích" (sinh key mới)

### 2.5. Kiểm thử nghiêm túc

- Test tích hợp cho toàn bộ luồng, chạy với MCP Server giả lập
- Chaos test tự động hoá, chạy trong CI thay vì làm thủ công một lần
- Regression test cho planner: chạy bộ test case mỗi khi sửa prompt, so với ngưỡng
- Test tải nhẹ: 50 run đồng thời

---

## Giai đoạn 3 — Trở thành nền tảng thật

**Khoảng 10-14 tuần · 2-3 người**

Đây là giai đoạn hệ thống chuyển từ "công cụ chạy theo yêu cầu" thành "nền tảng tự động hoá".

### 3.1. Trigger — thứ còn thiếu quan trọng nhất

Hiện tại workflow chỉ chạy khi người dùng bấm. Tự động hoá thật cần chạy khi có việc xảy ra.

| Loại trigger | Mô tả | Độ khó |
|---|---|---|
| Theo lịch | Cron — "mỗi thứ Sáu 5 giờ chiều" | Thấp |
| Webhook | Dịch vụ ngoài gọi vào khi có sự kiện | Trung bình |
| Polling | Định kỳ kiểm tra thay đổi với dịch vụ không có webhook | Trung bình |
| Điều kiện dữ liệu | "Khi có task quá hạn" — cần đánh giá liên tục | Cao |

Trigger làm thay đổi một giả định lớn của thiết kế hiện tại: **dry-run và duyệt thủ công không còn khả thi** cho workflow chạy tự động lúc 3 giờ sáng. Cần cơ chế thay thế — xem 3.2.

### 3.2. Lớp quản trị — phần quan trọng nhất của giai đoạn này

Khi workflow chạy tự động, câu hỏi "làm sao đảm bảo AI không làm bậy" trở lại, nhưng không còn lời giải là "hỏi người dùng".

**Chính sách duyệt (approval policy).** Thay vì duyệt từng lần, người dùng đặt quy tắc trước:

- Tự động duyệt nếu mọi bước ghi thuộc danh sách tool đã tin cậy
- Tự động duyệt nếu workflow này đã chạy thành công N lần với cùng hình dạng kế hoạch
- Luôn hỏi nếu có bước gửi tin nhắn ra ngoài tổ chức
- Luôn hỏi nếu số bản ghi bị tác động vượt ngưỡng

**Danh mục quyền tool.** Quản trị viên khai báo rõ: người dùng nào, được gọi tool nào, với giới hạn nào. Đây chính là thứ mà các dự án agent thất bại thường thiếu.

**Nhật ký kiểm toán.** Mọi hành động ghi, ai gây ra, từ workflow nào, với tham số gì, kết quả ra sao — bất biến, xuất được, giữ theo thời hạn quy định.

**Phát hiện trôi lệch.** So sánh hình dạng kế hoạch qua các lần chạy của cùng một workflow. Nếu tuần này AI sinh ra kế hoạch khác hẳn tuần trước cho cùng một mô tả, đó là tín hiệu cần con người xem lại — dù cả hai kế hoạch đều hợp lệ.

### 3.3. Đa tổ chức

- Mô hình tổ chức, nhóm, vai trò
- Kết nối MCP dùng chung ở cấp tổ chức, thay vì mỗi người tự kết nối
- Workflow chia sẻ trong nhóm
- Cô lập dữ liệu giữa các tổ chức — cần rà soát lại toàn bộ truy vấn

### 3.4. Mở rộng đường vào tool

Đồ án cố ý chỉ hỗ trợ MCP. Sản phẩm nên mở thêm, nhưng theo thứ tự ưu tiên:

1. **Cầu nối OpenAPI → MCP.** Người dùng dán một OpenAPI spec, hệ thống tự sinh MCP Server tạm. Đây là cách mở cửa cho hàng nghìn API mà không phá vỡ kiến trúc — mọi thứ vẫn đi qua một đường duy nhất.
2. **HTTP tool thủ công.** Cho người dùng tự định nghĩa một lời gọi HTTP đơn giản. Dành cho trường hợp không có spec.
3. **Thư viện MCP Server có sẵn.** Danh mục các server phổ biến, kết nối bằng một cú bấm.

### 3.5. Trải nghiệm người dùng ở mức sản phẩm

- Thư viện workflow mẫu — phần lớn người dùng bắt đầu bằng cách sửa mẫu, không viết từ đầu
- Trình sửa kế hoạch trực quan cho người muốn can thiệp sâu (lưu ý: đây là thứ đồ án cố ý không làm, giờ mới có lý do làm)
- Lịch sử và so sánh phiên bản workflow
- Thông báo qua email hoặc Slack khi run thất bại

### 3.6. Quan sát và chi phí

- OpenTelemetry cho toàn bộ luồng, trace xuyên từ request tới lời gọi MCP
- Bảng điều khiển vận hành: tỉ lệ thành công, độ trễ theo phân vị, lỗi theo loại
- **Theo dõi chi phí LLM theo từng người dùng** — đây là thứ dễ mất kiểm soát nhất
- Prompt caching để giảm chi phí; danh mục tool và system prompt ít thay đổi nên rất hợp
- Hạn mức chi tiêu, cảnh báo khi vượt

---

## Giai đoạn 4 — Vận hành ở quy mô

**Cần đội ngũ, không còn là việc của hai người**

Ghi lại để biết ranh giới, không phải để làm ngay.

### 4.1. Quyết định về Workflow Engine

Đến một ngưỡng nhất định, engine tự viết sẽ đụng trần. Dấu hiệu cần chuyển sang Temporal hoặc tương đương:

- Workflow chạy dài quá vài giờ
- Cần đảm bảo thực thi đúng-một-lần ở mức chặt hơn idempotency hiện tại
- Nhiều worker tranh chấp, cần điều phối phân tán thật sự
- Cần phiên bản hoá workflow đang chạy dở

Thiết kế hiện tại đã chuẩn bị sẵn cho việc này: DSL là dữ liệu thuần, state nằm trong database, engine chỉ là bộ thực thi. Thay engine không phải viết lại hệ thống.

### 4.2. Hạ tầng

- Nhiều worker, phân vùng hàng đợi theo tổ chức để một khách hàng không làm nghẽn cả hệ thống
- Phân mảnh bảng `run_events` và `step_attempts` theo thời gian, kèm chính sách dọn dẹp
- Cân nhắc vector store chuyên dụng nếu số tool vượt hàng chục nghìn — dưới ngưỡng đó pgvector vẫn tốt
- Sao lưu, khôi phục thảm hoạ, kiểm thử khôi phục định kỳ

### 4.3. Tuân thủ

Nếu có khách hàng doanh nghiệp: SOC 2, mã hoá khi lưu trữ, thời hạn lưu dữ liệu, quyền xoá dữ liệu, khu vực lưu trữ theo vùng.

---

## 5. Nợ kỹ thuật đã biết

Ghi ngay từ bây giờ để không quên. Cột "thời điểm trả" là gợi ý, không phải hạn chót cứng.

| Nợ | Vấn đề | Thời điểm trả |
|---|---|---|
| Phạm vi idempotency | Chặn cả việc chạy lại có chủ đích | Giai đoạn 2 |
| `run_events` không giới hạn | Phình vô hạn | Giai đoạn 3 |
| Số chiều vector cố định | Đổi model embedding phải tạo lại cột và index | Trước khi đổi model |
| Không có rate limit | `POST /runs` gọi LLM tốn tiền thật | Ngay khi mở cho người ngoài |
| Xác thực WebSocket chưa quy định | Lỗ hổng nếu công khai | Giai đoạn 2 |
| Credential lưu ở tầng ứng dụng | Nên chuyển sang dịch vụ quản lý bí mật chuyên dụng | Giai đoạn 3 |
| Chỉ một worker | Không chịu tải, không dự phòng | Giai đoạn 3 |
| Grammar điều kiện rất hẹp | Người dùng sẽ cần nhiều hơn | Mở rộng có kiểm soát, đừng bao giờ dùng eval |

---

## 6. Ba quyết định kiến trúc sẽ phải xét lại

**Plan-then-execute có còn đúng khi workflow phức tạp hơn?**
Kế hoạch tĩnh không xử lý được vòng lặp trên tập dữ liệu chưa biết trước ("với mỗi khách hàng trong danh sách, làm X"). Hướng mở rộng: thêm bước dạng `for_each` vào DSL, engine tự nhân bản bước con lúc chạy. Vẫn giữ được tính xác định. Đây là thay đổi DSL lớn nhất phía trước.

**Dry-run có còn khả thi khi có trigger tự động?**
Không, và đó là lý do cần chính sách duyệt ở 3.2. Nhưng cần cẩn thận: chính sách duyệt tự động là chỗ dễ mở cửa cho tai nạn nhất. Nguyên tắc nên giữ: mặc định luôn là hỏi, tự động duyệt phải là lựa chọn có chủ đích cho từng workflow cụ thể.

**Tool Retrieval có đủ khi số tool lên hàng nghìn?**
Semantic search trên mô tả tool sẽ đụng trần khi nhiều tool gần giống nhau. Hướng đi: phân cấp — chọn server trước, rồi chọn tool trong server; hoặc học từ lịch sử sử dụng thật của chính người dùng đó.

---

## 7. Những thứ nên cân nhắc KHÔNG làm

Quan trọng không kém danh sách nên làm:

**Đừng làm marketplace workflow sớm.** Nghe hấp dẫn nhưng cần khối lượng người dùng mới có giá trị, và kéo theo cả kiểm duyệt nội dung lẫn vấn đề bảo mật. Để sau cùng, nếu có.

**Đừng tự huấn luyện model.** Chi phí và công sức không tương xứng với lợi ích so với việc dùng API và tinh chỉnh prompt.

**Đừng đuổi theo mọi tính năng của Zapier.** Họ có hàng trăm người và mười năm. Lợi thế của hệ thống này nằm ở chỗ khác: mô tả bằng ngôn ngữ tự nhiên, và kết nối được bất kỳ MCP Server nào mà không chờ ai hỗ trợ. Đào sâu hai thứ đó.

**Đừng bỏ dry-run để chạy nhanh hơn.** Đây là thứ phân biệt hệ thống này với một agent chạy tự do. Mất nó là mất luận điểm cốt lõi.

---

## 8. Mốc đánh giá lại

Sau mỗi giai đoạn, nên dừng và hỏi ba câu:

1. **Có ai đang dùng thật không?** Nếu sau giai đoạn 2 mà chỉ có bạn dùng, thì vấn đề không nằm ở tính năng còn thiếu.
2. **Cái gì hỏng nhiều nhất?** Sửa đúng chỗ đó thay vì làm tiếp theo lộ trình.
3. **Có còn đáng làm không?** Nếu đến giai đoạn 3 mà thấy không dùng tới, dừng lại là quyết định đúng — đồ án đã hoàn thành mục đích của nó rồi.
