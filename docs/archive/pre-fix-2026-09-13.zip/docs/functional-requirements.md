# AI Workflow Automation Platform

**Đặc tả yêu cầu chức năng (Functional Requirements Specification)**

---

## 1. Quy ước

### 1.1. Mã yêu cầu

Định dạng: `FR-<MÃ MODULE>-<SỐ>`

| Mã | Module |
|---|---|
| `CON` | Connection & Tool Registry |
| `PLN` | Planning |
| `VAL` | Validation |
| `APR` | Dry-run & Approval |
| `EXE` | Execution Engine |
| `TRC` | Monitoring & Trace |
| `WFM` | Workflow Management |
| `USR` | User & Access |

### 1.2. Độ ưu tiên (MoSCoW)

| Mức | Ý nghĩa | Hệ quả |
|---|---|---|
| **M** (Must) | Bắt buộc | Thiếu thì hệ thống không chứng minh được luận điểm cốt lõi |
| **S** (Should) | Nên có | Ảnh hưởng đáng kể tới điểm, nhưng có thể giản lược |
| **C** (Could) | Có thì tốt | Cắt đầu tiên khi thiếu thời gian |
| **W** (Won't) | Ngoài phạm vi | Ghi rõ để tránh phình dự án |

### 1.3. Tác nhân

| Tác nhân | Mô tả |
|---|---|
| **Người dùng** | Người mô tả công việc, duyệt kế hoạch, theo dõi thực thi |
| **Hệ thống** | Backend (planner, validator, engine) |
| **MCP Server** | Hệ thống ngoài cung cấp tool, do người dùng kết nối |
| **LLM Provider** | Dịch vụ LLM ngoài, dùng cho planning và replan |

---

## 2. Tổng quan Use Case

```
                      ┌─────────────────────────────┐
                      │      Người dùng             │
                      └──────────────┬──────────────┘
                                     │
        ┌────────────────┬───────────┼───────────┬────────────────┐
        ▼                ▼           ▼           ▼                ▼
  UC-01            UC-02        UC-03       UC-04           UC-05
  Kết nối          Tạo          Duyệt       Theo dõi        Xem lại
  MCP Server       workflow     kế hoạch    thực thi        lịch sử
        │                │           │           │                │
        ▼                ▼           ▼           ▼                ▼
  ┌───────────┐   ┌───────────┐ ┌─────────┐ ┌──────────┐  ┌───────────┐
  │ Discovery │   │ Retrieval │ │ Dry-run │ │  Engine  │  │  Trace    │
  │ + Registry│   │ + Planner │ │         │ │ + Replan │  │  Store    │
  └───────────┘   └───────────┘ └─────────┘ └──────────┘  └───────────┘
```

### Luồng chính (UC-02 → UC-04)

```
Người dùng nhập mô tả
        ↓
Tool Retrieval chọn tool liên quan
        ↓
Planner sinh Workflow DSL
        ↓
Validator kiểm tra 3 tầng ──[fail]──► Sửa lại (tối đa 3 vòng) ──[quá 3]──► Báo lỗi
        ↓ [pass]
Dry-run: chạy bước read, mô phỏng bước write
        ↓
Người dùng duyệt ──[từ chối]──► Hủy / sửa mô tả
        ↓ [duyệt]
Engine thực thi ──[lỗi]──► Retry ──[vẫn lỗi]──► Replan / Fail
        ↓
Hoàn tất + lưu trace
```

---

## 3. Module CON — Kết nối và Tool Registry

| ID | Yêu cầu | Ưu tiên |
|---|---|---|
| **FR-CON-01** | Người dùng thêm được một MCP Server bằng cách nhập thông tin kết nối (URL/command, loại transport, thông tin xác thực nếu có) | M |
| **FR-CON-02** | Hệ thống kiểm tra kết nối và báo kết quả thành công/thất bại kèm lý do cụ thể | M |
| **FR-CON-03** | Sau khi kết nối, hệ thống tự động gọi `tools/list` để lấy danh sách tool và schema, lưu vào Tool Registry | M |
| **FR-CON-04** | Người dùng xem được danh sách tool đã discovery của từng server: tên, mô tả, tham số đầu vào | M |
| **FR-CON-05** | Người dùng ngắt kết nối / xóa một MCP Server; tool của server đó bị gỡ khỏi Registry | M |
| **FR-CON-06** | Hệ thống chỉ cho phép kết nối tới MCP Server nằm trong allow-list đã cấu hình | M |
| **FR-CON-07** | Thông tin xác thực được mã hóa khi lưu và không bao giờ được đưa vào prompt gửi tới LLM | M |
| **FR-CON-08** | Hệ thống sinh embedding cho từng tool khi discovery và lưu vào vector store | M |
| **FR-CON-09** | Hệ thống kiểm tra sức khỏe kết nối định kỳ và hiển thị trạng thái (connected / disconnected / error) | S |
| **FR-CON-10** | Người dùng làm mới (refresh) danh sách tool của một server khi server có thay đổi | S |
| **FR-CON-11** | Hệ thống tự động thử kết nối lại khi mất kết nối tạm thời | C |

**Tiêu chí nghiệm thu module CON**
- Kết nối được đồng thời tối thiểu 3 MCP Server thuộc các domain khác nhau
- Thêm một server mới hoàn toàn mà **không cần sửa hay build lại code lõi**
- Tool của server mới dùng được ngay trong lần tạo workflow kế tiếp

---

## 4. Module PLN — Lập kế hoạch

| ID | Yêu cầu | Ưu tiên |
|---|---|---|
| **FR-PLN-01** | Người dùng nhập mô tả công việc bằng ngôn ngữ tự nhiên (tiếng Việt và tiếng Anh) | M |
| **FR-PLN-02** | Hệ thống thực hiện Tool Retrieval để chọn top-K tool liên quan thay vì đưa toàn bộ tool vào context | M |
| **FR-PLN-03** | Hệ thống tách mô tả người dùng thành các sub-intent trước khi retrieval (query expansion) | S |
| **FR-PLN-04** | Retrieval kết hợp semantic search và keyword matching (hybrid) | S |
| **FR-PLN-05** | Hệ thống sinh Workflow Plan đúng định dạng DSL đã đặc tả, gồm các bước, quan hệ phụ thuộc, tham số và biểu thức tham chiếu | M |
| **FR-PLN-06** | Mỗi bước trong kế hoạch phải khai báo `side_effect` là `read` hoặc `write` | M |
| **FR-PLN-07** | Mọi bước `write` phải có `idempotency_key` | M |
| **FR-PLN-08** | Hệ thống cung cấp các giá trị runtime (thời điểm hiện tại, đầu tuần, cuối tuần...) thay vì để LLM tự tính | M |
| **FR-PLN-09** | Khi validate thất bại, hệ thống gửi thông tin lỗi cụ thể về LLM để sinh lại, tối đa 3 vòng | M |
| **FR-PLN-10** | Vượt quá 3 vòng, hệ thống dừng và báo người dùng kèm giải thích dễ hiểu về nguyên nhân | M |
| **FR-PLN-11** | Hệ thống lưu lại mô tả gốc của người dùng cùng với kế hoạch để phục vụ trace và replan | M |
| **FR-PLN-12** | Khi độ tin cậy chọn tool thấp hoặc mô tả mơ hồ, hệ thống hỏi lại người dùng để làm rõ thay vì đoán | S |
| **FR-PLN-13** | Hệ thống hỗ trợ tham số hóa workflow (khai báo `inputs` để tái sử dụng với giá trị khác nhau) | S |
| **FR-PLN-14** | Người dùng chọn được chiến lược planning (one-shot / incremental) để phục vụ thí nghiệm so sánh | C |

**Tiêu chí nghiệm thu module PLN**
- Plan validity rate ≥ 80% trên bộ test case ở mức đơn giản và trung bình
- Retrieval đạt Recall@10 ≥ 90% trên tool set 30 tool
- Sinh đúng kế hoạch cho workflow có nhánh song song và có điều kiện

---

## 5. Module VAL — Kiểm tra tính hợp lệ

| ID | Yêu cầu | Ưu tiên |
|---|---|---|
| **FR-VAL-01** | **Tầng 1 — Schema**: kiểm tra kế hoạch đúng cấu trúc DSL, đủ trường bắt buộc, đúng kiểu dữ liệu | M |
| **FR-VAL-02** | **Tầng 2 — Tool**: kiểm tra `server` và `name` tồn tại trong Tool Registry | M |
| **FR-VAL-03** | **Tầng 2 — Args**: kiểm tra tham số khớp `inputSchema` mà MCP Server khai báo (đủ trường bắt buộc, đúng kiểu) | M |
| **FR-VAL-04** | **Tầng 3 — Graph**: kiểm tra đồ thị phụ thuộc không có chu trình | M |
| **FR-VAL-05** | **Tầng 3 — Reference**: kiểm tra mọi biểu thức `${steps.X...}` trỏ tới bước thực sự chạy trước đó | M |
| **FR-VAL-06** | Kiểm tra mọi bước `write` đều có `idempotency_key` hợp lệ | M |
| **FR-VAL-07** | Biểu thức điều kiện được phân tích bằng parser riêng theo grammar hẹp; **không** dùng bất kỳ cơ chế thực thi động nào trên chuỗi do LLM sinh ra | M |
| **FR-VAL-08** | Lỗi validate được trả về dưới dạng có cấu trúc (vị trí lỗi, loại lỗi, mô tả) để phục vụ vòng sửa | M |
| **FR-VAL-09** | Hệ thống ghi nhận số vòng validate cho mỗi lần tạo workflow để phục vụ đo đạc | S |

**Tiêu chí nghiệm thu module VAL**
- Chặn được 100% các trường hợp: tool không tồn tại, thiếu tham số bắt buộc, sai kiểu, chu trình trong đồ thị, reference tới bước không tồn tại
- Có bộ test với kế hoạch lỗi cố ý cho từng loại

---

## 6. Module APR — Dry-run và duyệt

| ID | Yêu cầu | Ưu tiên |
|---|---|---|
| **FR-APR-01** | Hệ thống thực thi thật các bước `read` trong chế độ dry-run để lấy dữ liệu thực tế | M |
| **FR-APR-02** | Hệ thống **không** thực thi bất kỳ bước `write` nào trong chế độ dry-run | M |
| **FR-APR-03** | Với mỗi bước `write`, hệ thống hiển thị cụ thể hành động sẽ thực hiện, kèm giá trị tham số đã được resolve | M |
| **FR-APR-04** | Người dùng duyệt hoặc từ chối toàn bộ kế hoạch | M |
| **FR-APR-05** | Workflow chỉ được chuyển sang trạng thái thực thi sau khi có xác nhận rõ ràng của người dùng | M |
| **FR-APR-06** | Kế hoạch chờ duyệt có thời hạn; quá hạn tự hủy để tránh thực thi trên dữ liệu đã cũ | S |
| **FR-APR-07** | Người dùng sửa tay tham số của một bước trước khi duyệt; kế hoạch sau khi sửa phải validate lại | S |
| **FR-APR-08** | Người dùng tắt bỏ (skip) một bước không cần thiết trước khi duyệt | C |

**Tiêu chí nghiệm thu module APR**
- Chứng minh được bằng log rằng không có API ghi nào được gọi trong dry-run
- Preview hiển thị đủ thông tin để người dùng đánh giá được ý định của kế hoạch

---

## 7. Module EXE — Engine thực thi

| ID | Yêu cầu | Ưu tiên |
|---|---|---|
| **FR-EXE-01** | Engine xác định thứ tự thực thi từ quan hệ phụ thuộc giữa các bước | M |
| **FR-EXE-02** | Engine gọi tool qua MCP (`tools/call`) với tham số đã resolve | M |
| **FR-EXE-03** | Engine resolve biểu thức tham chiếu (`inputs`, `steps`, `runtime`) trước khi gọi tool | M |
| **FR-EXE-04** | Engine retry khi gặp lỗi tạm thời, dùng exponential backoff, giới hạn số lần theo cấu hình của bước | M |
| **FR-EXE-05** | Engine phân biệt lỗi tạm thời (429, 503, timeout) và lỗi vĩnh viễn (400, 404) — chỉ retry loại thứ nhất | M |
| **FR-EXE-06** | Engine kiểm tra `idempotency_key` trước khi thực thi bước `write`; nếu key đã thực thi thành công thì bỏ qua | M |
| **FR-EXE-07** | Mọi chuyển trạng thái của run và của từng bước được ghi xuống cơ sở dữ liệu ngay lập tức | M |
| **FR-EXE-08** | Engine xử lý `on_error` theo cấu hình: `fail` / `continue` / `replan` | M |
| **FR-EXE-09** | Engine đánh giá `condition` của bước và bỏ qua bước khi điều kiện không thỏa | M |
| **FR-EXE-10** | Sau khi khởi động lại, engine phát hiện các run đang dở và tiếp tục từ bước chưa hoàn thành | M |
| **FR-EXE-11** | Các bước không phụ thuộc nhau được thực thi song song | S |
| **FR-EXE-12** | Khi một bước lỗi vĩnh viễn và `on_error` là `replan`, engine phân loại lỗi và chọn chiến lược replan tương ứng | S |
| **FR-EXE-13** | Replan ưu tiên sửa cục bộ (chỉ bước lỗi) trước khi sinh lại toàn bộ kế hoạch | S |
| **FR-EXE-14** | Số vòng replan tối đa cho mỗi run là 2 | S |
| **FR-EXE-15** | Người dùng hủy một run đang chạy; engine dừng sau khi hoàn tất bước hiện tại | S |
| **FR-EXE-16** | Engine áp dụng timeout cho từng bước | S |
| **FR-EXE-17** | Engine giới hạn số lượng lời gọi đồng thời tới cùng một MCP Server | C |

**Tiêu chí nghiệm thu module EXE**
- Chaos test: kill process giữa chừng, khởi động lại, run tiếp tục đúng và **không** tạo side-effect trùng lặp
- Giả lập lỗi 429, engine retry đúng số lần với backoff tăng dần
- Workflow có 2 nhánh độc lập chạy song song, đo được thời gian ngắn hơn chạy tuần tự

---

## 8. Module TRC — Giám sát và truy vết

| ID | Yêu cầu | Ưu tiên |
|---|---|---|
| **FR-TRC-01** | Hệ thống ghi trace cho từng bước: tool, tham số gửi đi, kết quả trả về, trạng thái, số lần thử, thời gian bắt đầu/kết thúc | M |
| **FR-TRC-02** | Người dùng theo dõi tiến trình thực thi theo thời gian thực | M |
| **FR-TRC-03** | Giao diện hiển thị rõ khi một bước đang retry, kèm lý do và lần thử thứ mấy | M |
| **FR-TRC-04** | Giao diện hiển thị rõ khi replan được kích hoạt và kế hoạch thay đổi như thế nào | S |
| **FR-TRC-05** | Người dùng xem lại trace đầy đủ của các run đã kết thúc | M |
| **FR-TRC-06** | Trace hiển thị được ở dạng timeline theo thứ tự thời gian | M |
| **FR-TRC-07** | Thông tin nhạy cảm (credential, token) bị che trong trace | M |
| **FR-TRC-08** | Hệ thống thống kê các chỉ số phục vụ đánh giá: plan validity rate, số vòng sửa, completion rate, độ trễ | S |
| **FR-TRC-09** | Người dùng xuất trace của một run ra file để phục vụ báo cáo | C |

**Tiêu chí nghiệm thu module TRC**
- Từ trace, có thể tái dựng chính xác toàn bộ những gì đã xảy ra trong một run
- Giao diện cập nhật trạng thái trong vòng 1 giây kể từ khi engine thay đổi trạng thái

---

## 9. Module WFM — Quản lý workflow

| ID | Yêu cầu | Ưu tiên |
|---|---|---|
| **FR-WFM-01** | Hệ thống lưu lại kế hoạch đã sinh cùng mô tả gốc | M |
| **FR-WFM-02** | Người dùng xem danh sách các run đã thực hiện kèm trạng thái và thời điểm | M |
| **FR-WFM-03** | Người dùng chạy lại một workflow đã lưu; kết quả thực thi phải tái lập được với cùng đầu vào | S |
| **FR-WFM-04** | Người dùng đặt tên và lưu workflow để tái sử dụng | S |
| **FR-WFM-05** | Người dùng chạy lại workflow đã lưu với bộ `inputs` khác | C |
| **FR-WFM-06** | Người dùng xóa workflow và lịch sử run tương ứng | C |

---

## 10. Module USR — Người dùng và phân quyền

| ID | Yêu cầu | Ưu tiên |
|---|---|---|
| **FR-USR-01** | Hệ thống có cơ chế đăng nhập cơ bản | M |
| **FR-USR-02** | Mỗi người dùng chỉ thấy kết nối MCP, workflow và trace của chính mình | M |
| **FR-USR-03** | Credential của mỗi người dùng được lưu tách biệt và mã hóa | M |
| **FR-USR-04** | Hệ thống giới hạn scope quyền cho từng kết nối MCP theo nguyên tắc quyền tối thiểu | S |

---

## 11. Yêu cầu phi chức năng

### 11.1. Hiệu năng

| ID | Yêu cầu | Mục tiêu |
|---|---|---|
| **NFR-01** | Thời gian từ lúc nhập mô tả tới khi có kế hoạch | ≤ 15 giây với workflow ≤ 5 bước |
| **NFR-02** | Độ trễ của Tool Retrieval | ≤ 500ms với tool set 100 tool |
| **NFR-03** | Độ trễ cập nhật trạng thái lên giao diện | ≤ 1 giây |
| **NFR-04** | Số run đồng thời hệ thống xử lý được | ≥ 10 |

### 11.2. Độ tin cậy

| ID | Yêu cầu |
|---|---|
| **NFR-05** | Không mất trạng thái run khi hệ thống khởi động lại |
| **NFR-06** | Không tạo side-effect trùng lặp trong mọi tình huống retry hoặc resume |
| **NFR-07** | Lỗi của một MCP Server không làm sập toàn hệ thống |

### 11.3. Bảo mật

| ID | Yêu cầu |
|---|---|
| **NFR-08** | Mô tả tool và kết quả trả về từ MCP Server được xử lý như **dữ liệu**, không phải chỉ thị — tách bạch rõ trong cấu trúc prompt |
| **NFR-09** | Không dùng `eval` hay cơ chế thực thi động nào trên nội dung do LLM hoặc MCP Server sinh ra |
| **NFR-10** | Credential không xuất hiện trong log, trace, hoặc prompt |
| **NFR-11** | Chỉ kết nối được tới MCP Server trong allow-list |

### 11.4. Khả năng mở rộng

| ID | Yêu cầu |
|---|---|
| **NFR-12** | Thêm MCP Server mới không yêu cầu sửa, biên dịch lại hay triển khai lại code lõi |
| **NFR-13** | Thêm loại tool mới không yêu cầu thay đổi planner hay engine |

---

## 12. Ngoài phạm vi (Won't have)

Ghi rõ để chốt ranh giới:

| ID | Không làm | Lý do |
|---|---|---|
| **W-01** | Cắm REST API thô / OpenAPI spec trực tiếp | Chỉ hỗ trợ MCP; API riêng bọc qua MCP wrapper |
| **W-02** | Giao diện kéo-thả thiết kế workflow thủ công | Không phải trọng tâm; đó là mô hình của n8n/Zapier |
| **W-03** | Multi-tenant / multi-workspace | Một workspace demo là đủ |
| **W-04** | Marketplace hoặc chia sẻ workflow giữa người dùng | Ngoài phạm vi đồ án |
| **W-05** | Trigger tự động theo lịch hoặc webhook | Chạy theo yêu cầu người dùng |
| **W-06** | Tự huấn luyện hoặc fine-tune mô hình | Dùng LLM qua API |
| **W-07** | Rollback / compensating transaction cho bước đã ghi | Dùng dry-run để phòng ngừa thay vì khắc phục |

---

## 13. Ma trận truy vết

Đối chiếu yêu cầu với tiêu chí chấm điểm, để đảm bảo không có tiêu chí nào bị bỏ trống:

| Tiêu chí | Trọng số | Yêu cầu liên quan |
|---|---|---|
| System Architecture & Problem Formulation | 20% | FR-CON-03, FR-PLN-05, FR-VAL-01→07, NFR-12, NFR-13 |
| Technical Implementation | 25% | Toàn bộ FR-EXE, FR-CON-01→08 |
| AI / Algorithmic Component | 20% | FR-PLN-02→04, FR-PLN-09, FR-PLN-12, FR-PLN-14, FR-EXE-12→14 |
| Product Quality & Functionality | 15% | FR-APR-03→05, FR-TRC-02→06, FR-WFM-02 |
| Demonstration | 10% | FR-CON-01, FR-CON-05, FR-TRC-03, FR-TRC-04, FR-EXE-10 |
| Technical Explanation & Defense | 10% | FR-TRC-08, FR-VAL-09, FR-PLN-14 |

---

## 14. Phiên bản tối thiểu (MVP)

Nếu thời gian gấp, đây là tập yêu cầu **không được cắt** — đủ để hệ thống chứng minh được luận điểm cốt lõi và có thể demo trọn vẹn:

**Connection**: FR-CON-01, 02, 03, 04, 05, 06, 08
**Planning**: FR-PLN-01, 02, 05, 06, 07, 08, 09, 10, 11
**Validation**: FR-VAL-01 → 08
**Approval**: FR-APR-01 → 05
**Execution**: FR-EXE-01 → 10
**Trace**: FR-TRC-01, 02, 03, 05, 06, 07
**Management**: FR-WFM-01, 02
**User**: FR-USR-01, 02, 03

Tổng: **45 yêu cầu bắt buộc**. Mọi yêu cầu mức S và C chỉ làm sau khi toàn bộ danh sách trên đã hoàn tất và chạy ổn định.

> **Lưu ý về cấu hình B** (xem `docs/QUYET-DINH.md` QĐ-05): cấu hình B cắt **FR-EXE-10 (resume sau crash)** — một yêu cầu mức Must. Đây là sự thật cần nói rõ khi chọn: B đổi một yêu cầu bắt buộc lấy hai trụ của hạng mục AI. Nếu chọn B, MVP còn **44 yêu cầu**, và mục 13 dưới đây phải bỏ FR-EXE-10 khỏi dòng Demonstration.
