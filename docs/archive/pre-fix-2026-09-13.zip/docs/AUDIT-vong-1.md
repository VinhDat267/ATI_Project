# Biên bản rà soát tài liệu

Ngày rà soát: 12/09/2026 · Phạm vi: toàn bộ tài liệu và mã nguồn trước khi khởi động dự án

---

## 1. Đã kiểm tra những gì

| Hạng mục | Cách kiểm | Kết quả |
|---|---|---|
| Enum trạng thái: DB ↔ Zod | Đối chiếu tự động 3 enum | Khớp (11/7/5 giá trị) |
| Loại sự kiện: `events.ts` ↔ OpenAPI | Đối chiếu tự động 13 loại | Khớp hoàn toàn |
| Mã FR được trích dẫn | Quét toàn bộ `.md`, `.ts`, `.yaml`, `.sql` | 78/78 tồn tại, 0 mã ma |
| `$ref` trong OpenAPI | Phân tích YAML | 15 schema, không có ref hỏng |
| Khoá ngoại và enum trong SQL | Phân tích DDL | 14 bảng, mọi FK trỏ tới bảng có thật |
| Parser điều kiện | Chạy thật 20 trường hợp | 20/20 pass, 9 biểu thức độc hại đều bị chặn |
| Hàm `neutralize()` | Chạy thật 3 kiểu tấn công | Không phá được ranh giới khối |
| Test case ↔ danh mục tool | Đối chiếu tự động | 30 case, mọi `expected_tools` có thật |
| Hạng mục cắt ↔ độ ưu tiên FR | Đối chiếu tự động | Mọi thứ bị cắt đều là S hoặc C, không đụng Must |
| Đường dẫn nhắc trong tài liệu | Kiểm tra tồn tại file | Sau khi sửa: 0 đường dẫn hỏng |

---

## 2. Vấn đề đã phát hiện và đã sửa

### 2.1. Thiếu một mục trong danh sách ngoài phạm vi

`mo-ta-du-an.md` mục 7.2 liệt kê 6 mục, `functional-requirements.md` mục 12 liệt kê 7. Mục thiếu là **W-07 — không làm rollback / compensating transaction**.

Đây không phải lỗi hình thức. Rollback là câu hỏi hội đồng rất dễ hỏi ("nếu bước 3 lỗi mà bước 2 đã gửi Slack rồi thì sao?"), và câu trả lời của dự án là "dùng dry-run để phòng ngừa thay vì khắc phục". Nếu bản mô tả không ghi rõ đó là lựa chọn có chủ đích, nó trông như thiếu sót.

**Đã sửa:** bổ sung vào mục 7.2 kèm lý do.

### 2.2. Hai lộ trình cùng tồn tại, không rõ cái nào là chuẩn

`mo-ta-du-an.md` mục 9 có lộ trình 7 giai đoạn không gắn ngày. `KE-HOACH-6-TUAN.md` có lịch 6 tuần đã cắt bớt phạm vi. Hai bản không mâu thuẫn trực tiếp nhưng người đọc mới sẽ không biết theo cái nào.

**Đã sửa:** thêm ghi chú ở đầu mục 9 chỉ rõ bản kế hoạch 6 tuần là bản thi hành, và thêm thứ tự ưu tiên khi tài liệu mâu thuẫn vào `README.md` và `docs/00-BAT-DAU.md`:

> `KE-HOACH-6-TUAN.md` → `functional-requirements.md` → `mo-ta-du-an.md`

### 2.3. Tên công nghệ còn thuộc hệ sinh thái Java

Sau khi đổi stack sang TypeScript, hai chỗ vẫn so sánh với Camunda — một sản phẩm thuộc thế giới Java. Không sai về mặt kỹ thuật nhưng dễ bị hỏi vặn.

**Đã sửa:** đổi sang Temporal, Inngest, Trigger.dev — các lựa chọn có thật trong hệ sinh thái Node.

### 2.4. Bố cục file không khớp với cấu trúc repo mô tả trong README

Các file nằm rải rác trong thư mục kết quả, không theo đúng cây thư mục mà `README.md` mô tả. Nếu chép nguyên vào repo thì mọi đường dẫn trong tài liệu đều hỏng.

**Đã sửa:** ghép lại thành đúng cây thư mục, cập nhật bảng tài liệu trong README, và kiểm tra lại toàn bộ đường dẫn.

### 2.5. Thiếu điểm vào cho người mới

Có 11 tài liệu nhưng không có file nào nói "đọc cái gì trước". Người thứ hai nhận repo sẽ không biết bắt đầu từ đâu.

**Đã sửa:** thêm `docs/00-BAT-DAU.md` — thứ tự đọc theo vai trò, 30 phút đầu đọc gì, và năm điều cần biết trước khi viết dòng code đầu tiên.

---

## 3. Vấn đề đã ghi nhận, chưa sửa

Đây là những chỗ **cố ý để trống**, không phải bỏ sót. Ghi lại để không ai tưởng là quên.

| Chỗ trống | Vì sao chưa làm |
|---|---|
| Ba thư mục `apps/` mới có README giữ chỗ | Đây là phần sẽ code trong 6 tuần |
| `scripts/migrate.mjs`, `seed.mjs` chưa viết | Viết trong tuần 1, phụ thuộc lựa chọn ORM |
| Chưa chọn dứt khoát Prisma hay Drizzle | Drizzle hợp pgvector hơn; chốt ngày đầu tuần 1 |
| Xác thực WebSocket chưa quy định | Đã ghi trong `docs/API.md` mục 5 |
| Chưa có endpoint xoá idempotency cho demo | Đã ghi trong `docs/API.md` mục 5 và README |
| Chưa có rate limit | Chỉ cần khi mở cho người ngoài |
| Đề cương báo cáo, dàn ý slide | Chờ biết mẫu của trường và thời lượng bảo vệ |

---

## 4. Ba rủi ro chưa được tài liệu nào xử lý

Phần này là đánh giá, không phải lỗi tài liệu.

**Số chiều vector đang là giả định.** `VECTOR(1536)` được chọn theo model embedding phổ biến, nhưng chưa ai chốt model. Đổi sau khi đã có dữ liệu thì phải tạo lại cột và index. **Nên chốt trong tuần 1**, cùng lúc chốt DSL.

**Các ngưỡng trong tiêu chí nghiệm thu đều là giả định.** Plan validity rate ≥ 80%, Recall@10 ≥ 90%, độ trễ ≤ 15s — đặt theo cảm giác hợp lý, chưa đo. Sau bản chạy được đầu tiên nên đo thực tế rồi điều chỉnh. Cam kết một con số rồi không đạt sẽ khó ăn nói hơn là đặt mục tiêu vừa sức từ đầu.

**Giả định 20 giờ/tuần mỗi người chưa được kiểm chứng.** Toàn bộ kế hoạch 6 tuần dựa trên con số này. Nếu thực tế thấp hơn, mục 6 của bản kế hoạch có cấu hình rút gọn — nên quyết định ngay tuần 1 chứ không phải tuần 4.

---

## 5. Đánh giá tổng thể

Bộ tài liệu **đủ tin cậy để bắt đầu**. Các lớp khớp nhau: DSL ↔ database ↔ API ↔ sự kiện đều đã đối chiếu tự động và không lệch. Phần mã đã viết (DSL, parser, prompt) đã chạy thật và qua test.

Điểm mạnh: mọi quyết định thiết kế đều có ghi lý do, nên khi bảo vệ không phải nghĩ lại từ đầu.

Điểm yếu còn lại: các con số trong tiêu chí nghiệm thu chưa được kiểm chứng bằng dữ liệu thật. Đây là thứ chỉ giải quyết được sau khi có bản chạy được — không phải thứ sửa bằng cách viết thêm tài liệu.

**Việc nên làm ngay ngày đầu tiên:** hai người cùng đọc `docs/00-BAT-DAU.md`, rồi chốt ba thứ — model embedding, Prisma hay Drizzle, và quỹ thời gian thực tế mỗi tuần.
