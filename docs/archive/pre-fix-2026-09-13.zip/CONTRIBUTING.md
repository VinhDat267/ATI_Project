# Quy ước làm việc nhóm

Hai người, một codebase, sáu tuần. Tài liệu này tồn tại để không mất thời gian vào việc giẫm chân nhau.

---

## 1. Phân chia sở hữu

| Thư mục | Người sở hữu | Người kia |
|---|---|---|
| `apps/api/` | A | Đọc, không sửa trực tiếp |
| `apps/web/` | B | Đọc, không sửa trực tiếp |
| `apps/mcp-task-hub/` | B | — |
| `db/migrations/` | A | Báo trước nếu cần cột mới |
| `packages/dsl/` | **Cả hai** | Phải thống nhất trước khi sửa |
| `testdata/` | Cả hai | Ai gặp lỗi thì người đó thêm case |

"Không sửa trực tiếp" không phải quy tắc cứng — nếu thấy lỗi nhỏ trong phần của người kia thì cứ sửa và báo. Ý chính là: đừng làm lại kiến trúc phần của người khác mà không nói.

---

## 2. Hai mặt tiếp giáp — chốt tuần 1, đóng băng sau đó

**Mặt thứ nhất: Workflow DSL** (`packages/dsl/src/schema.ts`)
Backend sinh ra và thực thi nó, frontend vẽ sơ đồ từ nó.

**Mặt thứ hai: API contract** (`api/openapi.yaml` + `packages/dsl/src/events.ts`)
Backend phục vụ, frontend tiêu thụ.

Quy trình sửa sau khi đã đóng băng:

1. Người muốn sửa mở một issue ngắn: sửa gì, vì sao, ảnh hưởng phía kia thế nào
2. Hai người xác nhận
3. Sửa `packages/dsl`, chạy `npm run typecheck` toàn monorepo — compiler sẽ chỉ ra mọi chỗ gãy
4. Cả hai sửa phần của mình trong **cùng một PR**, không tách ra

Bước 4 quan trọng: tách ra thì repo sẽ ở trạng thái gãy giữa hai lần merge.

---

## 3. Git

**Nhánh:** `main` luôn chạy được. Làm việc trên nhánh `a/<việc>` hoặc `b/<việc>`.

```
a/engine-retry
b/man-hinh-trace
```

**Commit:** tiếng Việt hoặc tiếng Anh đều được, miễn nói rõ đã làm gì. Kèm mã FR khi có:

```
thêm idempotency guard cho bước write (FR-EXE-06)
sửa lỗi resolve reference khi output là mảng
```

**Merge:** tự merge nhánh của mình vào `main` nếu chỉ đụng phần mình sở hữu. Nếu đụng `packages/dsl` hoặc `db/migrations` thì người kia phải xem trước.

**Đừng dùng rebase trên nhánh đã push.** Hai người, không cần lịch sử đẹp, cần không mất việc.

---

## 4. Kiểm tra trước khi merge

```bash
npm run typecheck && npm run test
```

Nếu thấy chạy CI tốn công cấu hình, cứ chạy tay — nhưng chạy thật, đừng bỏ qua.

---

## 5. Về việc chạy engine chung tiến trình với API

Mặc định `WORKER_INLINE=true` — engine chạy trong cùng tiến trình với API server.

**Vì sao làm vậy cho đồ án:** một lệnh `npm run dev:api` là chạy được tất cả. Ít thứ phải khởi động, ít thứ hỏng lúc demo.

**Đánh đổi:** một run nặng sẽ làm chậm API. Ở quy mô đồ án không thành vấn đề.

**Cách tách sau này:** engine đã nhận việc qua BullMQ nên chỉ cần đặt `WORKER_INLINE=false` và chạy thêm một tiến trình worker riêng. Kiến trúc không cần đổi. Nên nhắc chi tiết này trong báo cáo — nó cho thấy quyết định đơn giản hoá là có chủ đích, không phải do không biết.

---

## 6. Ba thói quen

**Ghi số liệu từ lần chạy đầu tiên.** Bảng `planning_attempts` và `retrieval_logs` phải có dữ liệu ngay từ tuần 3, không đợi tuần 6.

**Gặp lỗi thật thì thêm test case.** Vào `testdata/test-cases.json`, kèm ghi chú lỗi gì.

**Quay video demo từ tuần 4, quay lại mỗi tuần.** Tuần 6 chỉ cần quay bản cuối.

---

## 7. Khi bị kẹt

Quy ước đơn giản: **kẹt quá 2 tiếng thì nói.** Sáu tuần không có chỗ cho một người im lặng vật lộn ba ngày với một vấn đề mà người kia biết cách giải.

Trước mỗi cổng quyết định trong `docs/KE-HOACH-6-TUAN.md`, hai người ngồi lại 15 phút: đạt chưa, có cần cắt gì không. Cắt sớm là quyết định, cắt muộn là tai nạn.
