# Bộ dữ liệu kiểm thử

- `tools.json` — 27 tool trên 3 MCP Server
- `test-cases.json` — 30 test case ở 3 mức độ phức tạp

Dùng cho ba mục đích: đo plan validity rate, đo Recall@K của Tool Retrieval, và regression test mỗi khi sửa prompt.

---

## 1. Thành phần

| | Số lượng |
|---|---|
| Tool: `task_hub` (tự viết) | 16 |
| Tool: `github` (công khai) | 7 |
| Tool: `filesystem` (công khai) | 4 |
| Test case: simple | 10 |
| Test case: medium | 12 |
| Test case: complex | 8 |

Đã kiểm tra chéo: mọi `expected_tools` đều tồn tại trong danh mục, không có id trùng.

---

## 2. Những gì bộ test bao phủ

| Khía cạnh | Số case | Ví dụ |
|---|---|---|
| Có bước ghi (cần idempotency) | 23 | hầu hết |
| Nhánh song song | 4 | `c01`, `c04`, `c07` |
| Điều kiện | 2 | `m08`, `c02` |
| Bắc cầu nhiều server | 6 | `m03`, `c07` (ba server) |
| Tiếng Anh | 3 | `s04`, `m06` |
| Kỳ vọng từ chối | 2 | `s10`, `c08` |
| Mơ hồ có chủ ý | 1 | `s05` |

**Hai case kỳ vọng từ chối là quan trọng nhất trong bộ test.** `s10` yêu cầu dịch thuật (không có tool nào làm được), `c08` yêu cầu xoá card (danh mục không có tool xoá). Đúng hành vi là trả về `name` bắt đầu bằng `"KHÔNG THỂ: "`, không phải bịa tool hay lấy tool gần giống dùng tạm. Nếu hệ thống pass 28 case còn lại nhưng fail hai case này, đó là dấu hiệu prompt đang khuyến khích mô hình đoán bừa — nguy hiểm hơn là một kế hoạch sai rõ ràng.

**Sáu tool không xuất hiện trong bất kỳ `expected_tools` nào** (`list_boards`, `list_lists`, `get_card`, `list_slack_channels`, `add_issue_comment`, `search_files`). Đây là cố ý: chúng làm **distractor** cho thí nghiệm retrieval. Một hệ thống retrieval tốt phải không kéo chúng vào top-K khi không liên quan.

---

## 3. Ba case đáng chú ý

**`m01`** — "tổng hợp task đã xong, ghi sheet, báo Slack". Đây là case chủ lực cho demo: ba bước tuần tự, data flow rõ ràng, dễ hiểu với người ngoài. Nên là case đầu tiên trong kịch bản bảo vệ.

**`m02`** — "gán cho người đang có ít task nhất". Đây là case **trả lời câu hỏi "khác gì Zapier?"**. Hệ thống phải gọi `list_members` để lấy dữ liệu, rồi mới quyết định gán cho ai. Zapier/n8n không làm được điều này bằng cấu hình if-else; nó đòi hỏi suy luận từ dữ liệu thật. Nên đưa vào demo ngay sau `m01`.

**`c04`** — "chuẩn bị họp sprint". Ba bước đọc hoàn toàn độc lập, nhánh song song rộng nhất trong bộ test. Dùng để demo DAG scheduling: trên màn hình trace sẽ thấy ba bước chạy cùng lúc, và đo được thời gian ngắn hơn hẳn so với chạy tuần tự.

---

## 4. Cách dùng cho thí nghiệm

### Thí nghiệm 1 — Tool Retrieval

Cần 3 quy mô tool set. Hiện có 27 tool, cách mở rộng:

| Quy mô | Cách đạt được |
|---|---|
| ~10 | Chỉ bật một nửa `task_hub` |
| ~20 | `task_hub` + `filesystem` (cấu hình 6 tuần) |
| ~50 | Bổ sung tool tổng hợp làm nhiễu, hoặc thêm `github` nếu kịp |

Về nhóm tool giả lập: nếu không đủ server thật, có thể sinh thêm bằng cách nhân bản tool có sẵn với tên và mô tả biến thể. Cách này hợp lệ cho việc đo Recall@K miễn là **nói rõ trong báo cáo** rằng đó là tool tổng hợp — đừng để hội đồng tự phát hiện.

Cách làm tốt hơn nếu có thời gian: thêm 2-3 MCP Server công khai thật ở domain khác hẳn (thời tiết, tìm kiếm web, cơ sở dữ liệu). Vừa đủ số lượng, vừa tăng độ khó thật cho retrieval vì mô tả tool đa dạng hơn.

### Thí nghiệm 2 — Chiến lược planning

Chạy toàn bộ 30 case với `planning_strategy: one_shot`, rồi chạy lại với `incremental`. So sánh `plan_validity_rate`, `avg_planning_attempts`, độ trễ và token. **Chạy mỗi cấu hình ít nhất 3 lần** vì LLM có tính ngẫu nhiên — một lần chạy không đủ kết luận.

### Thí nghiệm 3 — Chaos test

Chọn 5 case có nhiều bước write (`c01`, `c03`, `c05`, `c06`, `c07`), inject lỗi theo từng loại trong bảng phân loại ở mục 5.4. Quan trọng nhất: kill process giữa chừng ở case có 2+ bước write, khởi động lại, kiểm tra **không có side-effect trùng lặp**.

---

## 5. Nạp dữ liệu

```sql
-- Nạp test case vào bảng test_cases
INSERT INTO test_cases (label, complexity, prompt, expected_tool_names)
SELECT
  c->>'id',
  c->>'complexity',
  c->>'prompt',
  ARRAY(SELECT jsonb_array_elements_text(c->'expected_tools'))
FROM jsonb_array_elements(
  (pg_read_file('testdata/test-cases.json')::jsonb)->'cases'
) AS c;
```

`pg_read_file` cần quyền superuser — trong thực tế nên viết script nạp bằng Node thay vì SQL thuần.

---

## 6. Bảo trì bộ test

**Khi thêm tool mới vào MCP Server**: cập nhật `tools.json`, và cân nhắc có cần thêm test case không. Tool mới không có test case sẽ thành distractor — điều đó không sai, nhưng nên là lựa chọn có ý thức.

**Khi một lỗi thật xuất hiện lúc phát triển**: thêm ngay một test case tái hiện lỗi đó. Bộ test lớn dần theo những lỗi đã gặp là bộ test có giá trị nhất — nó ngăn lỗi cũ quay lại khi bạn sửa prompt cho lỗi mới.

**`expected_tools` là nhãn thủ công.** Nếu bạn đổi danh mục tool mà quên cập nhật nhãn, Recall@K sẽ sai mà không có gì báo. Nên viết một script kiểm tra chéo (như script đã dùng để kiểm tra file này) và chạy trong CI.
