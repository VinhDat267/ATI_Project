# Bắt đầu từ đâu

Tài liệu này dành cho người mới vào dự án. Đọc theo thứ tự dưới đây.

---

## Đọc trong 30 phút đầu

| Thứ tự | File | Vì sao |
|---|---|---|
| 1 | `docs/mo-ta-du-an.md` — mục 1 và 2 | Hệ thống làm gì, kiến trúc plan-then-execute và lý do chọn nó |
| 2 | `docs/wireframes.html` | Ba màn hình sẽ trông như thế nào — mở bằng trình duyệt |
| 3 | `docs/KE-HOACH-6-TUAN.md` | Lịch, phân công, và các cổng quyết định |
| 4 | `CONTRIBUTING.md` | Quy ước làm việc chung, đặc biệt mục 2 về hai mặt tiếp giáp |
| 5 | `docs/QUYET-DINH.md` | Stack đã chốt và lý do — tránh tranh luận lại từ đầu |
| 6 | `docs/AUDIT.md` phần II | **Đọc trước khi code.** Phạm vi hiện vượt quỹ thời gian — có một quyết định phải chọn |

Sáu file đó đủ để hiểu dự án và bắt đầu bàn việc.

---

## Đọc trước khi viết dòng code đầu tiên

Tuỳ vai trò:

**Nếu bạn làm backend / engine:**
- `docs/mo-ta-du-an.md` mục 3 (đặc tả DSL) và mục 5 (workflow engine)
- `db/DATABASE.md` — toàn bộ, đặc biệt mục 2 về bốn quyết định thiết kế
- `packages/dsl/src/schema.ts` — đây là hợp đồng, đọc kỹ
- `packages/dsl/PROMPTS.md` mục 1 — bốn lớp phòng vệ, bắt buộc đọc trước khi đụng vào prompt

**Nếu bạn làm frontend:**
- `docs/API.md` — toàn bộ, đặc biệt mục 2 (luồng) và mục 4 (cách mock để không phải chờ backend)
- `packages/dsl/src/events.ts` — 13 loại sự kiện, đây là thứ frontend tiêu thụ
- `docs/mo-ta-du-an.md` mục 6.2 — đặc tả ba màn hình

**Nếu bạn viết MCP Server:**
- `testdata/tools.json` — danh mục tool cần hiện thực
- `docs/mo-ta-du-an.md` mục 2.3 — vì sao dùng MCP

---

## Tra cứu khi cần

| File | Dùng khi |
|---|---|
| `docs/functional-requirements.md` | Cần biết chính xác một tính năng phải làm gì. Mục 14 là danh sách MVP. |
| `docs/openapi.yaml` | Viết hoặc gọi API. Sinh type bằng `npx openapi-typescript`. |
| `db/migrations/0001_init.sql` | Cấu trúc bảng |
| `testdata/TESTDATA.md` | Chạy thí nghiệm, hoặc thêm test case |
| `docs/LO-TRINH-DAY-DU.md` | Sau khi xong đồ án, nếu muốn làm tiếp |

---

## Năm điều cần biết trước khi bắt đầu

**1. `packages/dsl` là hợp đồng giữa hai người.** Sửa nó là thay đổi ảnh hưởng cả hai. Quy trình sửa ở `CONTRIBUTING.md` mục 2.

**2. AI không thực thi.** AI chỉ sinh kế hoạch dạng dữ liệu. Engine mới thực thi. Đây là quyết định kiến trúc gốc — mọi thứ khác bắt nguồn từ nó.

**3. Không bao giờ `eval` nội dung từ LLM hoặc MCP Server.** Điều kiện có parser riêng ở `packages/dsl/src/condition.ts`.

**4. Ghi số liệu từ lần chạy đầu tiên.** Hai bảng `planning_attempts` và `retrieval_logs` phải có dữ liệu từ tuần 3. Không ghi sớm thì tuần 6 phải chạy lại tất cả.

**5. Khi tài liệu mâu thuẫn nhau**, thứ tự ưu tiên:
`KE-HOACH-6-TUAN.md` (phạm vi thực tế) → `functional-requirements.md` (yêu cầu) → `mo-ta-du-an.md` (thiết kế và lý do).

Kế hoạch 6 tuần đã cắt bớt so với bản thiết kế đầy đủ. Điều đó là cố ý.
