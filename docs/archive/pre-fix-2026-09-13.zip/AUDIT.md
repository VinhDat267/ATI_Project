# Rà soát lần cuối — kiểm tra và phản biện

Ngày 12/09/2026 · sau khi đã chốt stack và quỹ thời gian

---

## Phần I — Kiểm tra nhất quán

| Hạng mục | Kết quả |
|---|---|
| Enum trạng thái: DB ↔ Zod | Khớp (11 / 7 / 5 giá trị) |
| 13 loại sự kiện: `events.ts` ↔ OpenAPI | Khớp hoàn toàn |
| 78 mã FR được trích dẫn | Không có mã ma |
| `$ref` trong OpenAPI | 15 schema, không hỏng |
| Khoá ngoại SQL | 14 bảng, mọi FK hợp lệ |
| Đường dẫn nhắc trong tài liệu | Chỉ còn `scripts/migrate.mjs` — cố ý chưa viết |

### Sáu chỗ trôi dạt đã sửa trong vòng này

Sau khi cắt phạm vi cho vừa 6 tuần, bản mô tả thiết kế vẫn mô tả những thứ đã cắt:

1. Mục 4.1 vẫn trình bày hybrid retrieval như phần bắt buộc → đã đánh dấu ngoài phạm vi 6 tuần
2. **Câu trả lời phản biện ở mục 10 tuyên bố có hybrid search** → đã sửa thành semantic. Đây là chỗ nguy hiểm nhất: đọc nguyên văn khi bảo vệ là tuyên bố một thứ không tồn tại trong mã nguồn.
3. Thí nghiệm 1 nêu 5 cấu hình và quy mô 10/30/60 tool → không còn khả thi với hai server (chỉ khoảng 20 tool). Đã sửa còn 3 cấu hình, quy mô 10/20/50 với tool tổng hợp làm nhiễu, kèm yêu cầu nói rõ trong báo cáo.
4. Kịch bản demo vẫn liệt kê GitHub như server bắt buộc → đã đánh dấu mục tiêu phụ
5. Bảng tech stack vẫn có keyword search không ghi chú → đã đánh dấu
6. `TESTDATA.md` vẫn hướng dẫn mở rộng lên 60 tool bằng ba server → đã sửa

---

## Phần II — Phản biện

Đây là phần quan trọng hơn.

### 1. Phạm vi vượt quỹ thời gian khoảng 70%

Ước lượng chi tiết từng hạng mục còn lại sau khi đã cắt:

| Nhóm | Giờ |
|---|---|
| Backend: MCP layer, engine, retry, resume, planner, validate, dry-run, WebSocket, retrieval, replan, REST | 133 |
| MCP Server `task_hub` (16 tool) | 16 |
| Frontend: ba màn hình + panel | 46 |
| Hạ tầng, sửa lỗi, ghép nối, việc phát sinh | 35 |
| **Tổng** | **230** |
| Quỹ đã chốt | 135 |
| **Chênh** | **+95 giờ — vượt 70%** |

Ước lượng này có thể sai lệch khoảng ±30%. Nhưng ngay cả ở mức lạc quan nhất (230 × 0,7 ≈ 161 giờ), nó vẫn vượt quỹ. Kết luận không đổi: **cấu hình hiện tại không vừa 135 giờ.**

Điều đó cũng có nghĩa là cách cắt ở vòng trước — bỏ hybrid retrieval và server thứ ba — chỉ tiết kiệm khoảng 15 giờ. Quá ít so với mức thiếu hụt.

### 2. Không thể vừa có engine mạnh, vừa có AI mạnh, vừa có ba màn hình đẹp

Đây là mâu thuẫn cốt lõi, và tài liệu hiện tại đang né nó bằng cách giữ cả ba.

Phải chọn. Hai cấu hình dưới đây đều vừa khoảng 145 giờ và đều mạch lạc:

**Cấu hình A — nghiêng về engine**

Giữ đầy đủ: retry, idempotency, resume sau crash, WebSocket real-time.
Cắt: replan, query expansion. Retrieval chỉ semantic thuần.

- Mạnh: Technical Implementation (25%) và Architecture (20%)
- Yếu: AI/Algorithmic (20%) chỉ còn semantic search và các thí nghiệm

**Cấu hình B — nghiêng về AI** ← khuyến nghị

Giữ: retrieval có query expansion, replan cục bộ có phân loại lỗi.
Cắt: resume sau crash. Thay WebSocket bằng polling 2 giây. Gộp màn hình 1 và 2 (xem điểm 3).

- Mạnh: AI/Algorithmic (20%) có hai trụ thật
- Technical Implementation vẫn ổn: retry, idempotency, validate 3 tầng, dry-run đã đủ chứng minh năng lực kỹ thuật

**Vì sao khuyến nghị B:** resume sau crash tốn khoảng 10 giờ nhưng chỉ demo được bằng cách kill process — một khoảnh khắc, khó gây ấn tượng bằng replan tự sửa kế hoạch. Còn WebSocket: polling 2 giây cho trải nghiệm gần như giống hệt trong demo. Quan trọng là **giữ nguyên bảng `run_events` và trường `seq`** — nâng cấp lên WebSocket sau này chỉ là đổi tầng vận chuyển, không đụng dữ liệu, và nói được điều đó khi bảo vệ là một điểm cộng chứ không phải điểm trừ.

Cấu hình A mạnh hơn nếu hội đồng thiên về hệ thống. B mạnh hơn nếu hội đồng thiên về AI. Đề tài nằm ở track AI Agent, nên B hợp hơn.

### 3. Màn hình 1 và 2 nên gộp làm một

Không phải để tiết kiệm thời gian — mà vì thiết kế hiện tại đang tách sai.

Người dùng xem kế hoạch, bấm "chạy thử", rồi lại xem gần như cùng nội dung ở màn hình duyệt. Hai lần đọc cùng một kế hoạch. Gộp thành một màn hình có hai trạng thái — "kế hoạch" và "đã chạy thử, chờ duyệt" — vừa ít thao tác hơn, vừa tiết kiệm khoảng 8 giờ.

Đây là phản biện về sản phẩm, không phải về thời gian. Nên làm kể cả nếu dư thời gian.

### 4. `task_hub` 16 tool là quá nhiều

Bộ test case chỉ thực sự dùng 10 tool. Sáu tool còn lại tồn tại để làm nhiễu cho thí nghiệm retrieval — nhưng tool tổng hợp cũng làm được việc đó mà không tốn công hiện thực.

Đề xuất: hiện thực **8 tool thật**, đủ chạy các case demo chính (`m01`, `m02`, `c01`); phần nhiễu dùng tool tổng hợp. Tiết kiệm khoảng 8 giờ.

### 5. Hai điểm yếu không sửa được bằng cách viết thêm tài liệu

**Các ngưỡng nghiệm thu vẫn là phỏng đoán.** Plan validity rate ≥ 80%, Recall@10 ≥ 90%, độ trễ ≤ 15 giây — chưa có dữ liệu nào chống lưng. Nên coi là mục tiêu tham khảo, và **chỉ đưa con số cam kết vào báo cáo sau khi đã đo thật ở tuần 3-4**.

**Luận điểm "platform" yếu đi khi chỉ có hai server.** Kịch bản demo mạnh nhất là cắm một MCP Server chưa từng dùng ngay trước hội đồng. Với `filesystem` chạy local thì vẫn làm được, nhưng thuyết phục hơn nhiều nếu có thêm một server công khai thật. Đây là lý do nên giữ GitHub làm mục tiêu phụ chứ không xoá khỏi kế hoạch — chi phí chủ yếu là cấu hình OAuth, không phải viết mã.

---

## Phần III — Ba việc cần làm trước khi bắt đầu

1. **Chọn cấu hình A hay B.** Đây là quyết định duy nhất còn lại, và nó thay đổi phân công tuần 3-5. Không chọn thì mặc định sẽ làm cả hai và thiếu 95 giờ.
2. **Gộp màn hình 1 và 2** trong wireframe, trước khi người làm frontend bắt tay.
3. **Giảm `task_hub` xuống 8 tool**, cập nhật `testdata/tools.json` cho khớp.

---

## Đánh giá tổng thể

Bộ tài liệu **nhất quán về mặt kỹ thuật**: các lớp DSL, database, API, sự kiện đã đối chiếu tự động và không lệch; phần mã đã viết đều chạy thật và qua test.

Điểm yếu duy nhất còn lại là **phạm vi vượt quỹ thời gian** — và đó không phải lỗi tài liệu, mà là một quyết định chưa được đưa ra. Sau khi chọn cấu hình và áp ba điều chỉnh ở trên, kế hoạch sẽ vừa khoảng 145 giờ: vẫn chặt hơn 135 một chút, nhưng nằm trong sai số ước lượng và đã có thứ tự cắt dự phòng ở mục 6 của bản kế hoạch.

Điều đáng nói cuối cùng: phát hiện thiếu 95 giờ **ở tuần 0 là tin tốt**. Phát hiện ở tuần 4 mới là tai nạn.
