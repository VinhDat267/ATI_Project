# Quyết định kỹ thuật đã chốt

Các lựa chọn còn để mở sau vòng rà soát. Mỗi mục ghi: chốt gì, vì sao, và chi phí đổi ý về sau.

---

## QĐ-01 — ORM: Drizzle

**Chốt:** `drizzle-orm` + `drizzle-kit`, dùng chung với file SQL viết tay đã có.

**Vì sao không phải Prisma:**

| | Drizzle | Prisma |
|---|---|---|
| pgvector | Kiểu `vector()` sẵn trong `pg-core` | Phải viết raw query, client sinh ra không hiểu kiểu |
| SQL thô | Hạng nhất, giữ nguyên kiểu trả về | Có `$queryRaw` nhưng mất type |
| Migration viết tay | Chấp nhận file `.sql` sẵn có | Muốn tự quản lý migration theo cách riêng |
| Kích thước | Nhẹ, không có bước sinh mã | Nặng hơn, cần `prisma generate` |

Yếu tố quyết định là hybrid retrieval: truy vấn kết hợp `vector_cosine_ops` với `to_tsvector` không phải thứ ORM nào cũng diễn đạt gọn. Drizzle cho viết SQL thô mà vẫn giữ được kiểu; Prisma thì phải thoát ra `$queryRaw` và mất hết lợi ích của ORM ở đúng chỗ quan trọng nhất.

Thêm nữa: `db/migrations/0001_init.sql` đã viết tay và đã rà soát. Drizzle chấp nhận nó như nguồn sự thật. Prisma sẽ muốn bạn khai báo lại schema bằng ngôn ngữ riêng của nó — làm hai lần một việc.

**Chi phí đổi ý:** trung bình. Phải viết lại tầng truy cập dữ liệu, nhưng schema và migration giữ nguyên.

---

## QĐ-02 — Embedding: `text-embedding-3-small`, 1536 chiều

**Chốt:** giữ nguyên `EMBEDDING_DIM=1536` như trong `.env.example`.

**Vì sao:**

- Đa ngôn ngữ đủ tốt. Đây là ràng buộc thật của dự án: mô tả tool của `task_hub` bằng tiếng Việt, của `github` và `filesystem` bằng tiếng Anh, còn prompt người dùng thì tiếng Việt. Model chỉ mạnh tiếng Anh sẽ hỏng ở đúng chỗ này.
- Chi phí không đáng kể. 60 tool nhúng một lần là vài nghìn token.
- Hỗ trợ cắt chiều (Matryoshka) — muốn giảm xuống 512 để thử nghiệm thì không cần đổi model.

**Đánh đổi đã cân nhắc:** phải thêm một API key thứ hai bên cạnh Anthropic. Phương án thay thế là chạy model cục bộ qua transformers.js (`multilingual-e5-small`, 384 chiều) — không cần mạng, hợp với demo dự phòng. Nhưng chất lượng thấp hơn, mà Recall@K lại là số liệu chính của thí nghiệm 1.

**Nếu muốn phương án cục bộ:** dùng nó làm dự phòng cho demo, không phải cấu hình chính. Khi đó cần cột vector thứ hai chứ không phải đổi cột hiện có.

**Chi phí đổi ý:** thấp. Một migration đổi số chiều cột, rồi nhúng lại toàn bộ tool — vài giây với quy mô này.

---

## QĐ-03 — Backend framework: Fastify

**Chốt:** `fastify` + `@fastify/websocket` cho `apps/api`.

**Vì sao không phải NestJS:** nhiều khuôn mẫu, nhiều khái niệm phải học (module, provider, decorator). Với 6 tuần và một người làm backend, chi phí đó không đổi lại được gì — dự án này không có nhiều module cần tổ chức, phần khó nằm ở engine chứ không ở tầng HTTP.

**Vì sao không phải Next.js API routes:** không host được tiến trình chạy nền lâu dài. Engine cần một vòng lặp sống liên tục, gửi heartbeat, giữ kết nối WebSocket. Next.js không được thiết kế cho việc đó. Frontend vẫn dùng Next.js — chỉ là không dùng phần API của nó.

**Vì sao Fastify hợp:**
- Nhẹ, ít khái niệm, TypeScript tốt sẵn
- `@fastify/websocket` đủ dùng cho luồng sự kiện
- Chạy chung tiến trình với BullMQ worker dễ dàng (`WORKER_INLINE=true`)
- Sinh được route từ JSON Schema — hợp với việc đã có `openapi.yaml`

**Chi phí đổi ý:** trung bình, nhưng chỉ ảnh hưởng tầng HTTP. Engine, DSL, database không đụng tới.

---

## QĐ-04 — Quỹ thời gian: 135 giờ xây dựng

**Chốt:** 5-6 buổi/tuần mỗi người (buổi = khối liền 2-3 giờ), hai người tương đương, không có tuần nào biết trước sẽ bận.

| | |
|---|---|
| Mỗi người | ~14 giờ/tuần |
| Tổng 6 tuần | ~165 giờ người |
| Quỹ xây dựng | ~135 giờ (tuần 6 dành cho thí nghiệm, báo cáo, demo) |

**Hệ quả — đã áp vào `docs/KE-HOACH-6-TUAN.md`:**
- Cắt hybrid retrieval, chỉ giữ semantic + query expansion
- Cắt MCP Server thứ ba (GitHub) — thành mục tiêu phụ
- Giữ hai server: `task_hub` tự viết và `filesystem` chạy local

**Rủi ro đã biết:** quỹ này không có đệm. Mục 6 của bản kế hoạch có thứ tự cắt khi bị chậm, kèm dấu hiệu nhận biết ở từng cổng quyết định.

---

## QĐ-05 — Cấu hình A hay B: **CHƯA CHỐT**

Vòng rà soát cuối (`docs/AUDIT.md` phần II) phát hiện: ngay cả sau các lần cắt ở QĐ-04, phạm vi vẫn cần khoảng 230 giờ so với quỹ 135 giờ — vượt khoảng 70%.

Phải chọn một trong hai:

| | Cấu hình A — nghiêng engine | Cấu hình B — nghiêng AI *(khuyến nghị)* |
|---|---|---|
| Giữ | retry, idempotency, resume sau crash, WebSocket | retrieval + query expansion, replan cục bộ |
| Cắt | replan, query expansion | resume sau crash; WebSocket → polling 2 giây |
| Mạnh ở | Technical Implementation (25%), Architecture (20%) | AI/Algorithmic (20%) |

Kèm ba điều chỉnh áp cho cả hai: gộp màn hình 1 và 2, giảm `task_hub` xuống 8 tool, giữ GitHub làm mục tiêu phụ.

**Đây là quyết định duy nhất còn lại.** Không chọn thì mặc định sẽ làm cả hai và thiếu 95 giờ. Lý do đầy đủ ở `docs/AUDIT.md` phần II mục 2.

---

## Tóm tắt cần thêm vào `.env` và `package.json`

```bash
# .env — thêm
OPENAI_API_KEY=            # chỉ dùng cho embedding
```

```json
// apps/api/package.json — phụ thuộc chính
"fastify", "@fastify/websocket", "@fastify/cors",
"drizzle-orm", "postgres", "bullmq", "ioredis",
"@anthropic-ai/sdk", "openai",
"@modelcontextprotocol/sdk", "zod", "@wap/dsl"
```

```json
// apps/web/package.json — phụ thuộc chính
"next", "react", "@wap/dsl", "openapi-fetch"
```

---

## Còn để mở có chủ đích

Những thứ dưới đây **không cần chốt bây giờ** — chốt sớm chỉ tốn thời gian tranh luận mà chưa đủ thông tin:

| Mục | Chốt khi nào |
|---|---|
| Thư viện vẽ DAG (React Flow hay tự dựng bằng flex) | Tuần 2, khi dựng màn hình 1. Flex là đủ, xem ghi chú cuối `docs/wireframes.html` |
| Thư viện biểu đồ cho phần số liệu | Tuần 6 |
| Cách xác thực WebSocket | Tuần 3, nếu chọn cấu hình A |
| CI chạy ở đâu | Khi thấy cần; chạy tay cũng được trong 6 tuần |
