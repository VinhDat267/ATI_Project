# Thiết kế cơ sở dữ liệu

PostgreSQL 16 + pgvector. DDL đầy đủ ở `migrations/0001_init.sql`.

---

## 1. Sơ đồ quan hệ

```
users
  │
  ├──< mcp_servers ──< tools  (embedding + search_text)
  │
  └──< workflows ──< workflow_versions ──< runs
                          │                  │
                    (plan JSONB)             ├──< step_states ──< step_attempts
                                             ├──< approvals
                                             ├──< run_events
                                             ├──< planning_attempts
                                             └──< retrieval_logs

  └──< idempotency_records   (phạm vi theo user, không theo run)
```

---

## 2. Bốn quyết định cần giải thích khi bảo vệ

### 2.1. Tách `workflow_versions` khỏi `runs`

Kế hoạch (definition) và lượt chạy (runtime state) là hai thứ khác nhau, và đây là điều kiện tiên quyết để có resume — đúng như mục 3.5 của bản mô tả dự án.

`workflow_versions` **bất biến** sau khi tạo. Mỗi lần replan sinh một version mới với `origin = 'replan'` và `parent_id` trỏ về version cũ. Nhờ vậy:

- Trace của một run cũ luôn trỏ đúng kế hoạch đã thực sự chạy, kể cả sau khi replan đổi kế hoạch
- Có thể so sánh kế hoạch trước và sau replan để hiển thị trên UI (FR-TRC-04)
- Chạy lại một workflow cũ (FR-WFM-03) là tạo `run` mới trỏ vào cùng version — kết quả tái lập được

Nếu gộp plan vào thẳng `runs`, mỗi lần replan sẽ ghi đè và mất lịch sử.

### 2.2. Phạm vi idempotency là `(user_id, key)`

Đây là quyết định có đánh đổi, nên nói rõ.

Ba lựa chọn:

| Phạm vi | Chống được gì | Vấn đề |
|---|---|---|
| `(run_id, key)` | Retry và resume trong cùng một run | Chạy lại workflow lần hai sẽ gửi Slack lần hai |
| `(workflow_id, key)` | Thêm: chạy lại cùng workflow | Hai workflow khác nhau cùng gửi một báo cáo vẫn trùng |
| **`(user_id, key)`** | Mọi trường hợp trên | Cần key được đặt tên tốt |

Chọn `(user_id, key)` vì các key trong kế hoạch vốn đã nhúng dữ liệu phân biệt — ví dụ `post_report_${runtime.week_start}`. Tuần sau key tự khác, nên không bị chặn nhầm. Trong cùng một tuần, dù retry, resume, hay người dùng bấm chạy lại, hành động ghi chỉ xảy ra đúng một lần. Đây mới là ý nghĩa thật của idempotency.

Hệ quả cần lưu ý khi demo: chạy lại cùng một workflow trong cùng tuần sẽ bị bỏ qua bước ghi (`status = 'deduplicated'`). Cần một API xoá `idempotency_records` cho môi trường demo, hoặc dùng dữ liệu khác nhau giữa các lần chạy thử.

### 2.3. `step_states` giữ hiện tại, `step_attempts` giữ lịch sử

Hai bảng thay vì một, vì hai nhu cầu khác nhau:

- Engine cần đọc nhanh "bước này đang thế nào, output là gì" → `step_states`, một dòng mỗi bước, có cập nhật
- Trace cần "lần thử thứ 2 lỗi gì, args gửi đi là gì, mất bao lâu" → `step_attempts`, append-only, không bao giờ sửa

Gộp lại thì hoặc mất lịch sử retry (không demo được cơ chế retry), hoặc phải nhét mảng vào JSONB rồi tự quản lý — bất tiện và dễ sai.

`step_attempts.resolved_args` lưu args **sau khi** resolve `${...}`. Đây là thứ quý nhất khi debug: biết chính xác giá trị nào đã được gửi đi.

### 2.4. `run_events` — nguồn sự thật cho WebSocket

Engine không đẩy trực tiếp ra WebSocket. Engine ghi vào `run_events` với `seq` tăng dần, rồi lớp phát sóng đọc từ đó.

Lợi ích:
- Client mất kết nối rồi nối lại: gửi `seq` cuối cùng đã nhận, server trả phần còn thiếu — không mất sự kiện
- Xem lại run cũ dùng chung một luồng dữ liệu với xem real-time, không cần hai đường code
- Demo quay video xong vẫn phát lại được nguyên trạng

---

## 3. Chỉ mục và lý do

| Chỉ mục | Phục vụ |
|---|---|
| `tools_embedding_idx` (HNSW, cosine) | Semantic search trong Tool Retrieval |
| `tools_search_idx` (GIN, tsvector) | Thành phần keyword của hybrid retrieval |
| `runs_active_idx` (partial) | Truy vấn resume sau crash — chỉ quét run còn dở |
| `approvals_run_pending_idx` (partial unique) | Đảm bảo mỗi run chỉ có tối đa một phiếu chờ duyệt |
| `step_attempts_state_idx` | Dựng timeline trace theo thứ tự |

Chỉ mục partial (`WHERE ...`) được dùng ở hai chỗ vì bảng `runs` sẽ lớn dần nhưng số run đang chạy luôn nhỏ — quét toàn bảng mỗi lần khởi động là lãng phí không cần thiết.

---

## 4. Cơ chế resume (FR-EXE-10)

Ba cột trên `runs` phối hợp với nhau:

- `claimed_by` — định danh worker đang giữ run
- `claimed_at` — thời điểm nhận
- `heartbeat_at` — worker cập nhật định kỳ khi còn sống

Khi khởi động, worker quét các run có `status IN ('running','replanning','dry_running')` và `heartbeat_at` cũ hơn ngưỡng (ví dụ 60 giây). Đó là các run mồ côi do crash. Worker giành lấy bằng một câu `UPDATE ... WHERE claimed_by IS NULL OR heartbeat_at < ...` có điều kiện, rồi đọc `step_states` để biết bước nào đã xong, bước nào cần chạy tiếp.

Idempotency đảm bảo bước `write` đã hoàn tất trước khi crash không bị thực hiện lại.

---

## 5. Bảng phục vụ đo đạc

Ba bảng cuối (`planning_attempts`, `retrieval_logs`, `test_cases`) không phục vụ chức năng — chúng tồn tại để sinh số liệu cho các thí nghiệm ở mục 8.2 của bản mô tả dự án.

Lời khuyên: **tạo chúng ngay từ đầu, đừng để đến lúc cần mới thêm.** Nếu engine không ghi số liệu trong suốt quá trình phát triển, đến giai đoạn 6 sẽ phải chạy lại toàn bộ test case từ con số không. Ghi sẵn thì đến lúc viết báo cáo chỉ cần truy vấn.

Ví dụ truy vấn cho báo cáo:

```sql
-- Plan validity rate theo chiến lược (thí nghiệm 2)
SELECT strategy,
       count(*) FILTER (WHERE attempt_no = 1 AND passed) * 1.0 / count(DISTINCT run_id)
         AS first_try_success_rate,
       avg(attempt_no)     AS avg_attempts,
       avg(latency_ms)     AS avg_latency_ms
FROM planning_attempts
GROUP BY strategy;

-- Recall@K theo biến thể retrieval (thí nghiệm 1)
SELECT variant,
       total_tools_in_registry,
       avg(
         cardinality(ARRAY(
           SELECT unnest(ground_truth_tool_ids)
           INTERSECT
           SELECT unnest(retrieved_tool_ids)
         ))::float
         / nullif(cardinality(ground_truth_tool_ids), 0)
       ) AS recall_at_k,
       avg(latency_ms) AS avg_latency_ms
FROM retrieval_logs
WHERE ground_truth_tool_ids IS NOT NULL
GROUP BY variant, total_tools_in_registry
ORDER BY total_tools_in_registry, variant;
```

---

## 6. Những chỗ cần điều chỉnh khi triển khai

**Số chiều vector.** `VECTOR(1536)` là giả định theo model embedding phổ biến. Chốt model trước rồi sửa con số cho khớp — đổi sau khi đã có dữ liệu thì phải tạo lại cột và index.

**Cấu hình text search.** Đang dùng `'simple'` thay vì `'english'` vì tên tool thường là định danh kỹ thuật (`list_cards`, `create_issue`), không phải văn bản tự nhiên — stemming tiếng Anh dễ làm hỏng khớp chính xác. Nếu mô tả tool dài và mang tính văn xuôi thì cân nhắc đổi.

**Mã hoá credential.** `auth_encrypted BYTEA` chỉ là chỗ chứa. Việc mã hoá làm ở tầng ứng dụng, khoá lấy từ biến môi trường, không lưu trong DB.

**Chưa có phân mảnh hay dọn dẹp.** `run_events` và `step_attempts` sẽ phình theo thời gian. Ở quy mô đồ án thì không cần xử lý, nhưng nên nhắc trong phần hạn chế của báo cáo — cho thấy bạn biết vấn đề tồn tại.
